import React, { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { inventoryAPI, branchAPI } from '../utils/api';
import { formatIDR, formatNumber } from '../utils/format';
import { DownloadSimple, MagnifyingGlass, FilePdf } from '@phosphor-icons/react';
import { toast } from 'sonner';

const STATUS_STYLES = {
  'Perlu Order': 'bg-red-500/10 text-red-600 border-red-500/20',
  'Over Stok': 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
  'Stop Order': 'bg-gray-500/10 text-gray-600 border-gray-500/20',
  'Normal': 'bg-green-500/10 text-green-600 border-green-500/20',
  'Error': 'bg-red-500/10 text-red-600 border-red-500/20'
};

const STOCK_STATUS_STYLES = {
  FMV: 'bg-green-500/10 text-green-700',
  MMV: 'bg-blue-500/10 text-blue-700',
  SMV: 'bg-yellow-500/10 text-yellow-700',
  NMV: 'bg-gray-500/10 text-gray-700'
};

export function Inventory() {
  const { user } = useAuth();
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [branches, setBranches] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(0);
  const pageSize = 20;

  useEffect(() => {
    loadBranches();
  }, []);

  useEffect(() => {
    loadInventory();
  }, [selectedBranch, selectedStatus, page]);

  const loadBranches = async () => {
    try {
      const response = await branchAPI.getAll();
      setBranches(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const loadInventory = async () => {
    setLoading(true);
    try {
      const params = {
        skip: page * pageSize,
        limit: pageSize
      };
      if (selectedBranch !== 'all') params.branch = selectedBranch;
      if (selectedStatus !== 'all') params.status = selectedStatus;
      
      const response = await inventoryAPI.getAll(params);
      setItems(response.data.items);
      setTotal(response.data.total);
    } catch (error) {
      toast.error('Gagal memuat data inventory');
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async () => {
    try {
      const params = {};
      if (selectedBranch !== 'all') params.branch = selectedBranch;
      if (selectedStatus !== 'all') params.status = selectedStatus;
      
      const response = await inventoryAPI.exportExcel(params);
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `mip_report_${new Date().toISOString().slice(0,10)}.xlsx`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      toast.success('Export Excel berhasil!');
    } catch (error) {
      toast.error('Gagal export data');
    }
  };

  const handleExportPDF = async () => {
    try {
      const params = {};
      if (selectedBranch !== 'all') params.branch = selectedBranch;
      if (selectedStatus !== 'all') params.status = selectedStatus;
      
      const response = await inventoryAPI.exportPDF(params);
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `mip_report_${new Date().toISOString().slice(0,10)}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      toast.success('Export PDF berhasil!');
    } catch (error) {
      toast.error('Gagal export PDF');
    }
  };

  const filteredItems = searchTerm
    ? items.filter(item =>
        item.product_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.product_description?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : items;

  const totalPages = Math.ceil(total / pageSize);

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">Data Parts</p>
            <h1 className="text-3xl lg:text-4xl font-bold tracking-tight">Inventory</h1>
            <p className="text-muted-foreground mt-1">Total: {total.toLocaleString()} parts</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={handleExport} className="gap-2" data-testid="export-excel-button">
              <DownloadSimple size={18} weight="bold" />
              Export Excel
            </Button>
            <Button onClick={handleExportPDF} variant="outline" className="gap-2" data-testid="export-pdf-button">
              <FilePdf size={18} weight="bold" />
              Export PDF
            </Button>
          </div>
        </div>

        <Card className="border-border">
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="relative">
                <MagnifyingGlass size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Cari part number / deskripsi..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                  data-testid="search-input"
                />
              </div>
              {user?.role !== 'partman' && (
                <Select value={selectedBranch} onValueChange={(v) => { setSelectedBranch(v); setPage(0); }}>
                  <SelectTrigger data-testid="branch-select">
                    <SelectValue placeholder="Semua Cabang" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Cabang</SelectItem>
                    {branches.map((b) => (
                      <SelectItem key={b.code} value={b.name}>{b.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
              <Select value={selectedStatus} onValueChange={(v) => { setSelectedStatus(v); setPage(0); }}>
                <SelectTrigger data-testid="status-select">
                  <SelectValue placeholder="Semua Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Status</SelectItem>
                  <SelectItem value="Perlu Order">Perlu Order</SelectItem>
                  <SelectItem value="Over Stok">Over Stok</SelectItem>
                  <SelectItem value="Normal">Normal</SelectItem>
                  <SelectItem value="Stop Order">Stop Order</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 border-b border-border">
                  <tr>
                    <th className="text-left px-4 py-3 font-semibold uppercase text-xs tracking-wider">Part Number</th>
                    <th className="text-left px-4 py-3 font-semibold uppercase text-xs tracking-wider">Deskripsi</th>
                    {user?.role !== 'partman' && (
                      <th className="text-left px-4 py-3 font-semibold uppercase text-xs tracking-wider">Cabang</th>
                    )}
                    <th className="text-right px-4 py-3 font-semibold uppercase text-xs tracking-wider">Qty Hand</th>
                    <th className="text-right px-4 py-3 font-semibold uppercase text-xs tracking-wider">Qty Order</th>
                    <th className="text-right px-4 py-3 font-semibold uppercase text-xs tracking-wider">Price</th>
                    <th className="text-right px-4 py-3 font-semibold uppercase text-xs tracking-wider">Gross Cost</th>
                    <th className="text-right px-4 py-3 font-semibold uppercase text-xs tracking-wider">Avg Dmd</th>
                    <th className="text-center px-4 py-3 font-semibold uppercase text-xs tracking-wider">Stk Status</th>
                    <th className="text-center px-4 py-3 font-semibold uppercase text-xs tracking-wider">Phase</th>
                    <th className="text-right px-4 py-3 font-semibold uppercase text-xs tracking-wider">MIP</th>
                    <th className="text-right px-4 py-3 font-semibold uppercase text-xs tracking-wider">SOQ</th>
                    <th className="text-center px-4 py-3 font-semibold uppercase text-xs tracking-wider">Status</th>
                    <th className="text-left px-4 py-3 font-semibold uppercase text-xs tracking-wider">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan={13} className="text-center py-16 text-muted-foreground">
                        Loading...
                      </td>
                    </tr>
                  ) : filteredItems.length === 0 ? (
                    <tr>
                      <td colSpan={13} className="text-center py-16 text-muted-foreground">
                        Belum ada data. Upload data untuk memulai.
                      </td>
                    </tr>
                  ) : (
                    filteredItems.map((item, idx) => (
                      <tr key={idx} className="border-b border-border hover:bg-accent/50 transition-colors" data-testid={`inventory-row-${idx}`}>
                        <td className="px-4 py-3 font-mono text-xs">{item.product_number}</td>
                        <td className="px-4 py-3">{item.product_description}</td>
                        {user?.role !== 'partman' && (
                          <td className="px-4 py-3 text-xs text-muted-foreground">{item.branch}</td>
                        )}
                        <td className="px-4 py-3 text-right">{formatNumber(item.qty_on_hand)}</td>
                        <td className="px-4 py-3 text-right">{formatNumber(item.qty_on_order)}</td>
                        <td className="px-4 py-3 text-right font-mono text-xs">{formatIDR(item.unit_cost)}</td>
                        <td className="px-4 py-3 text-right font-mono text-xs">{formatIDR(item.gross_cost || 0)}</td>
                        <td className="px-4 py-3 text-right">{item.avg_demand}</td>
                        <td className="px-4 py-3 text-center">
                          <span className={`inline-block px-2 py-0.5 rounded text-xs font-medium ${STOCK_STATUS_STYLES[item.stock_status] || 'bg-gray-500/10 text-gray-600'}`}>
                            {item.stock_status}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center">
                          <span className={`inline-block px-2 py-0.5 rounded text-xs font-medium ${
                            item.phase === 'Phase In' ? 'bg-green-500/10 text-green-700' :
                            item.phase === 'Phase Out' ? 'bg-gray-500/10 text-gray-700' :
                            'bg-yellow-500/10 text-yellow-700'
                          }`}>
                            {item.phase || '-'}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right font-semibold">{formatNumber(item.mip)}</td>
                        <td className="px-4 py-3 text-right font-semibold">{formatNumber(item.soq)}</td>
                        <td className="px-4 py-3 text-center">
                          <span className={`inline-block px-2 py-1 rounded border text-xs font-medium ${STATUS_STYLES[item.status] || ''}`}>
                            {item.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-xs">{item.action}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {totalPages > 1 && (
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Halaman {page + 1} dari {totalPages}
            </p>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setPage((p) => Math.max(0, p - 1))}
                disabled={page === 0}
                data-testid="prev-page-button"
              >
                Previous
              </Button>
              <Button
                variant="outline"
                onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                disabled={page >= totalPages - 1}
                data-testid="next-page-button"
              >
                Next
              </Button>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
