import React, { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { dashboardAPI, branchAPI } from '../utils/api';
import { formatIDR, formatIDRShort, formatNumber } from '../utils/format';
import { Package, ArrowsClockwise, ArrowsInLineHorizontal, CurrencyDollar, TrendUp, TrendDown } from '@phosphor-icons/react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const PHASE_COLORS = {
  'Phase In': 'hsl(142, 71%, 45%)',
  'Phase Out': 'hsl(0, 0%, 40%)',
  'Neutral': 'hsl(43, 96%, 56%)'
};

const STOCK_STATUS_COLORS = {
  FMV: 'hsl(142, 71%, 45%)',
  MMV: 'hsl(220, 70%, 50%)',
  SMV: 'hsl(43, 96%, 56%)',
  NMV: 'hsl(0, 0%, 40%)'
};

export function DashboardMIP() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [branches, setBranches] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState('all');

  useEffect(() => { loadBranches(); }, []);
  useEffect(() => { loadStats(); }, [selectedBranch]);

  const loadBranches = async () => {
    try {
      const r = await branchAPI.getAll();
      setBranches(r.data);
    } catch (e) { console.error(e); }
  };

  const loadStats = async () => {
    try {
      const branch = selectedBranch === 'all' ? '' : selectedBranch;
      const r = await dashboardAPI.getMIPStats(branch);
      setStats(r.data);
    } catch (e) { console.error(e); }
  };

  const phaseData = stats ? [
    { name: 'Phase In', value: stats.phase_in_count, color: PHASE_COLORS['Phase In'] },
    { name: 'Phase Out', value: stats.phase_out_count, color: PHASE_COLORS['Phase Out'] },
    { name: 'Neutral', value: stats.neutral_count, color: PHASE_COLORS['Neutral'] }
  ].filter(d => d.value > 0) : [];

  const stockData = stats?.stock_status_distribution?.map(s => ({
    name: s._id || '?',
    count: s.count,
    color: STOCK_STATUS_COLORS[s._id] || '#888'
  })) || [];

  const phaseBreakdown = stats?.phase_breakdown || [];

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">Monthly Analysis</p>
            <h1 className="text-3xl lg:text-4xl font-bold tracking-tight">Dashboard MIP</h1>
            <p className="text-muted-foreground mt-1">Minimum Inventory Point & Phase Analysis</p>
          </div>
          {user?.role !== 'partman' && (
            <Select value={selectedBranch} onValueChange={setSelectedBranch}>
              <SelectTrigger className="w-full sm:w-64" data-testid="branch-filter">
                <SelectValue placeholder="Pilih Cabang" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Cabang</SelectItem>
                {branches.map(b => <SelectItem key={b.code} value={b.name}>{b.name}</SelectItem>)}
              </SelectContent>
            </Select>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="Total Parts" value={formatNumber(stats?.total_parts || 0)} icon={Package} color="bg-blue-500/10 text-blue-600" testId="mip-total-parts" />
          <StatCard title="Phase In" value={formatNumber(stats?.phase_in_count || 0)} icon={TrendUp} color="bg-green-500/10 text-green-600" testId="mip-phase-in" />
          <StatCard title="Phase Out" value={formatNumber(stats?.phase_out_count || 0)} icon={TrendDown} color="bg-gray-500/10 text-gray-600" testId="mip-phase-out" />
          <StatCard title="Total Gross Cost" value={formatIDRShort(stats?.total_gross_cost || 0)} icon={CurrencyDollar} color="bg-primary/10 text-primary" testId="mip-gross-cost" tooltip={formatIDR(stats?.total_gross_cost || 0)} />
        </div>

        <Card className="border-border border-l-4 border-l-yellow-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground font-medium">Total Over Stock Cost</p>
                <p className="text-3xl font-bold mt-2 tracking-tight text-yellow-700" data-testid="mip-overstock-cost">
                  {formatIDR(stats?.total_over_stok_cost || 0)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">Nilai inventory yang melebihi MIP</p>
              </div>
              <div className="p-3 rounded-md bg-yellow-500/10">
                <ArrowsInLineHorizontal size={32} weight="fill" className="text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="border-border">
            <CardHeader><CardTitle className="text-xl">Phase In vs Phase Out</CardTitle></CardHeader>
            <CardContent>
              {phaseData.length > 0 ? (
                <ResponsiveContainer width="100%" height={280}>
                  <PieChart>
                    <Pie data={phaseData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={2} dataKey="value"
                         label={(e) => `${e.name}: ${e.value}`}>
                      {phaseData.map((e, i) => <Cell key={i} fill={e.color} />)}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              ) : <EmptyChart />}
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader><CardTitle className="text-xl">Stock Status Distribution</CardTitle></CardHeader>
            <CardContent>
              {stockData.length > 0 ? (
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={stockData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
                    <YAxis stroke="hsl(var(--muted-foreground))" />
                    <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }} />
                    <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                      {stockData.map((e, i) => <Cell key={i} fill={e.color} />)}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : <EmptyChart />}
            </CardContent>
          </Card>
        </div>

        <Card className="border-border">
          <CardHeader><CardTitle className="text-xl">Phase Breakdown by Cost</CardTitle></CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 border-b border-border">
                  <tr>
                    <th className="text-left px-4 py-3 font-semibold uppercase text-xs tracking-wider">Phase</th>
                    <th className="text-right px-4 py-3 font-semibold uppercase text-xs tracking-wider">Jumlah Parts</th>
                    <th className="text-right px-4 py-3 font-semibold uppercase text-xs tracking-wider">Gross Cost</th>
                    <th className="text-right px-4 py-3 font-semibold uppercase text-xs tracking-wider">Over Stok Cost</th>
                  </tr>
                </thead>
                <tbody>
                  {phaseBreakdown.length === 0 ? (
                    <tr><td colSpan={4} className="text-center py-16 text-muted-foreground">Belum ada data. Upload data MIP untuk melihat breakdown.</td></tr>
                  ) : (
                    phaseBreakdown.map((p, i) => (
                      <tr key={i} className="border-b border-border" data-testid={`phase-row-${i}`}>
                        <td className="px-4 py-3 font-medium">
                          <span className="inline-flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: PHASE_COLORS[p.phase] || '#888' }} />
                            {p.phase}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right">{formatNumber(p.count)}</td>
                        <td className="px-4 py-3 text-right font-mono">{formatIDR(p.gross_cost)}</td>
                        <td className="px-4 py-3 text-right font-mono text-yellow-700">{formatIDR(p.over_stok_cost)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardHeader><CardTitle className="text-xl">Info Perhitungan MIP</CardTitle></CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
              <div className="space-y-2">
                <p className="font-semibold uppercase tracking-wider text-xs">Formula</p>
                <p className="text-muted-foreground">MIP = Avg.Dmd × (O/C + Avg.L/T + SS L/T + SS Dmd)</p>
                <p className="text-muted-foreground">SOQ = MIP − (Qty on Hand + Qty on Order) + Back Order</p>
              </div>
              <div className="space-y-2">
                <p className="font-semibold uppercase tracking-wider text-xs">Phase Classification</p>
                <p className="text-muted-foreground"><span className="text-green-600 font-medium">Phase In</span>: demand di ≥ 3 bulan berbeda</p>
                <p className="text-muted-foreground"><span className="text-gray-600 font-medium">Phase Out</span>: demand di &lt; 2 bulan berbeda</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}

function EmptyChart() {
  return <div className="h-72 flex items-center justify-center text-muted-foreground">Belum ada data</div>;
}

function StatCard({ title, value, icon: Icon, color, testId, tooltip }) {
  return (
    <Card className="border-border hover:-translate-y-1 transition-transform duration-200" data-testid={testId} title={tooltip}>
      <CardContent className="pt-6">
        <div className="flex items-start justify-between">
          <div className="min-w-0 flex-1">
            <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground font-medium">{title}</p>
            <p className="text-2xl lg:text-3xl font-bold mt-2 tracking-tight truncate">{value}</p>
          </div>
          <div className={`p-2 rounded-md ${color} flex-shrink-0`}>
            <Icon size={24} weight="fill" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
