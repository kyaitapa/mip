"""Backend tests for Toyota MIP Calculator API"""
import os
import io
import pytest
import requests
from openpyxl import Workbook

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL") or "https://branch-parts-tracker.preview.emergentagent.com"
BASE_URL = BASE_URL.rstrip("/")
API = f"{BASE_URL}/api"

ADMIN = {"email": "admin@toyota.com", "password": "Admin123!@#"}
MANAGER = {"email": "manager@toyota.com", "password": "Manager123!"}
PARTMAN = {"email": "partman@toyota.com", "password": "Partman123!"}


def _login(session, creds):
    r = session.post(f"{API}/auth/login", json=creds, timeout=30)
    return r


# ---------------- AUTH ----------------
class TestAuth:
    def test_admin_login(self):
        s = requests.Session()
        r = _login(s, ADMIN)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["role"] == "admin"
        assert data["email"] == "admin@toyota.com"
        # httpOnly cookies
        assert "access_token" in s.cookies, f"access_token cookie missing; got {s.cookies.keys()}"
        assert "refresh_token" in s.cookies

    def test_manager_login(self):
        s = requests.Session()
        r = _login(s, MANAGER)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["role"] == "manager"
        assert data["branch"] == "PLAZA TOYOTA KYAI TAPA"

    def test_partman_login(self):
        s = requests.Session()
        r = _login(s, PARTMAN)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["role"] == "partman"
        assert data["branch"] == "PLAZA TOYOTA KYAI TAPA"

    def test_invalid_credentials_returns_401(self):
        s = requests.Session()
        r = _login(s, {"email": "nobody@toyota.com", "password": "wrongpass"})
        assert r.status_code in (401, 429), r.text

    def test_auth_me(self):
        s = requests.Session()
        _login(s, ADMIN)
        r = s.get(f"{API}/auth/me", timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["email"] == "admin@toyota.com"

    def test_auth_me_unauthenticated(self):
        r = requests.get(f"{API}/auth/me", timeout=30)
        assert r.status_code == 401

    def test_logout_clears_cookies(self):
        s = requests.Session()
        _login(s, ADMIN)
        r = s.post(f"{API}/auth/logout", timeout=30)
        assert r.status_code == 200
        # After logout, /me should fail
        s2 = requests.Session()
        r2 = s2.get(f"{API}/auth/me", timeout=30)
        assert r2.status_code == 401

    def test_register_new_user(self):
        import uuid
        email = f"test_{uuid.uuid4().hex[:8]}@toyota.com"
        r = requests.post(f"{API}/auth/register", json={
            "email": email, "password": "TestPass123!", "name": "Test User",
            "role": "partman", "branch": "PLAZA TOYOTA TENDEAN"
        }, timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["email"] == email
        assert data["role"] == "partman"


# ---------------- BRANCHES ----------------
class TestBranches:
    def test_get_branches(self):
        s = requests.Session()
        _login(s, ADMIN)
        r = s.get(f"{API}/branches", timeout=30)
        assert r.status_code == 200, r.text
        branches = r.json()
        assert isinstance(branches, list)
        assert len(branches) == 6, f"Expected 6 branches, got {len(branches)}"
        names = [b["name"] for b in branches]
        assert "PLAZA TOYOTA KYAI TAPA" in names
        assert "PLAZA TOYOTA BANDUNG" in names


# ---------------- MIP CALCULATOR (unit) ----------------
class TestMIPCalculator:
    def test_mip_calculation_logic(self):
        import sys
        sys.path.insert(0, "/app/backend")
        from mip_calculator import calculate_mip_for_part
        result = calculate_mip_for_part({
            "mar_demand": 10, "apr_demand": 12, "mei_demand": 8, "jun_demand": 11,
            "qty_on_hand": 5, "qty_on_order": 0
        })
        assert result["frequency"] == 4
        assert result["avg_demand"] == 10.25
        assert result["stock_status"] == "FMV"
        assert result["mip"] > 0
        # soq = max(0, mip - qty_on_hand - qty_on_order)
        expected_soq = max(0, result["mip"] - 5 - 0)
        assert result["soq"] == expected_soq

    def test_status_stop_order_when_no_demand(self):
        import sys
        sys.path.insert(0, "/app/backend")
        from mip_calculator import calculate_mip_for_part
        result = calculate_mip_for_part({
            "mar_demand": 0, "apr_demand": 0, "mei_demand": 0, "jun_demand": 0,
            "qty_on_hand": 5, "qty_on_order": 0
        })
        assert result["frequency"] == 0
        assert result["status"] == "Stop Order"


# ---------------- INVENTORY UPLOAD ----------------
def _make_xlsx():
    wb = Workbook()
    ws = wb.active
    ws.append(["Product Number", "Product Description", "Qty on Hand", "Qty on Order",
               "Unit Cost", "Mar", "Apr", "Mei", "Jun"])
    ws.append(["TEST-P001", "TEST Oil Filter", 2, 0, 50000, 10, 12, 8, 11])   # Perlu Order likely
    ws.append(["TEST-P002", "TEST Brake Pad", 500, 0, 100000, 5, 6, 4, 5])    # Over Stok
    ws.append(["TEST-P003", "TEST Old Part", 10, 0, 25000, 0, 0, 0, 0])       # Stop Order
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


class TestInventory:
    def test_upload_and_calculations(self):
        s = requests.Session()
        _login(s, ADMIN)
        buf = _make_xlsx()
        files = {"file": ("test.xlsx", buf, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}
        r = s.post(f"{API}/inventory/upload?branch=PLAZA%20TOYOTA%20KYAI%20TAPA",
                   files=files, timeout=60)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["uploaded_count"] == 3, f"Expected 3 uploads, got {data}"

    def test_get_inventory_admin(self):
        s = requests.Session()
        _login(s, ADMIN)
        # Ensure at least our 3 test items exist (in case a parallel test wiped them)
        r0 = s.get(f"{API}/inventory?limit=1", timeout=30)
        if r0.status_code == 200 and r0.json()["total"] < 3:
            buf = _make_xlsx()
            files = {"file": ("test.xlsx", buf, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}
            s.post(f"{API}/inventory/upload?branch=PLAZA%20TOYOTA%20KYAI%20TAPA", files=files, timeout=60)
        r = s.get(f"{API}/inventory?limit=100", timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        assert "items" in data
        assert "total" in data
        assert data["total"] >= 3
        # Verify computed fields present
        found_p001 = next((i for i in data["items"] if i.get("product_number") == "TEST-P001"), None)
        assert found_p001 is not None
        for key in ("avg_demand", "max_demand", "frequency", "mad", "stock_status", "mip", "soq", "status", "action"):
            assert key in found_p001, f"Missing key {key}"

    def test_get_inventory_partman_filtered_by_branch(self):
        s = requests.Session()
        _login(s, PARTMAN)
        r = s.get(f"{API}/inventory?limit=100", timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        for item in data["items"]:
            assert item.get("branch") == "PLAZA TOYOTA KYAI TAPA"

    def test_inventory_pagination(self):
        s = requests.Session()
        _login(s, ADMIN)
        r = s.get(f"{API}/inventory?skip=0&limit=1", timeout=30)
        assert r.status_code == 200
        data = r.json()
        assert len(data["items"]) <= 1


# ---------------- DASHBOARD ----------------
class TestDashboard:
    def test_dashboard_stats(self):
        s = requests.Session()
        _login(s, ADMIN)
        # Ensure data exists (parallel destructive test may have wiped)
        r0 = s.get(f"{API}/inventory?limit=1", timeout=30)
        if r0.status_code == 200 and r0.json()["total"] < 3:
            wb = Workbook(); ws = wb.active
            ws.append(["Product Number", "Product Description", "Qty on Hand", "Qty on Order",
                       "Unit Cost", "Mar", "Apr", "Mei", "Jun"])
            for i in range(3):
                ws.append([f"DBS-{i}", f"desc{i}", 2, 0, 1000, 5, 6, 4, 5])
            buf = io.BytesIO(); wb.save(buf); buf.seek(0)
            files = {"file": ("d.xlsx", buf, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}
            s.post(f"{API}/inventory/upload", params={"branch": "PLAZA TOYOTA KYAI TAPA"}, files=files, timeout=60)
        r = s.get(f"{API}/dashboard/stats", timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        for k in ("total_parts", "perlu_order", "over_stok", "normal", "stop_order", "stock_status_distribution"):
            assert k in data, f"Missing {k}"
        assert data["total_parts"] >= 3


# ---------------- NOTIFICATIONS ----------------
class TestNotifications:
    def test_get_notifications_manager(self):
        s = requests.Session()
        _login(s, MANAGER)
        r = s.get(f"{API}/notifications", timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        assert isinstance(data, list)


# ---------------- EXPORT ----------------
class TestExport:
    def test_export_excel(self):
        s = requests.Session()
        _login(s, ADMIN)
        r = s.get(f"{API}/export/excel", timeout=60)
        assert r.status_code == 200, r.text
        assert "spreadsheetml" in r.headers.get("content-type", "")
        assert len(r.content) > 100


# ---------------- USERS (admin only) ----------------
class TestUsers:
    def test_get_users_admin(self):
        s = requests.Session()
        _login(s, ADMIN)
        r = s.get(f"{API}/users", timeout=30)
        assert r.status_code == 200, r.text
        users = r.json()
        assert isinstance(users, list)
        assert len(users) >= 3

    def test_get_users_manager_forbidden(self):
        s = requests.Session()
        _login(s, MANAGER)
        r = s.get(f"{API}/users", timeout=30)
        assert r.status_code == 403

    def test_get_users_partman_forbidden(self):
        s = requests.Session()
        _login(s, PARTMAN)
        r = s.get(f"{API}/users", timeout=30)
        assert r.status_code == 403


# ---------------- HISTORY & DELETE (new features) ----------------
# Same class name as TestInventory to pin loadscope to same worker (avoid parallel races)
class TestInventoryHistoryDelete:
    def _upload_batch(self, session, branch="PLAZA TOYOTA KYAI TAPA", prefix="HIST"):
        wb = Workbook()
        ws = wb.active
        ws.append(["Product Number", "Product Description", "Qty on Hand", "Qty on Order",
                   "Unit Cost", "Mar", "Apr", "Mei", "Jun"])
        for i in range(1, 6):
            ws.append([f"{prefix}-{i:03d}", f"Test part {i}", 2, 0, 10000, 5, 6, 4, 5])
        buf = io.BytesIO(); wb.save(buf); buf.seek(0)
        files = {"file": ("h.xlsx", buf, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}
        r = session.post(f"{API}/inventory/upload", params={"branch": branch}, files=files, timeout=60)
        assert r.status_code == 200, r.text
        return r.json()

    def test_history_endpoint_returns_batches(self):
        s = requests.Session()
        _login(s, ADMIN)
        self._upload_batch(s, prefix="HISTA")
        r = s.get(f"{API}/inventory/history", timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        assert isinstance(data, list)
        assert len(data) >= 1
        b = data[0]
        for k in ("branch", "upload_date", "count", "perlu_order_count", "first_upload"):
            assert k in b, f"Missing key {k} in history entry"
        assert isinstance(b["count"], int)
        assert isinstance(b["perlu_order_count"], int)

    def test_history_partman_only_own_branch(self):
        s = requests.Session()
        _login(s, PARTMAN)
        r = s.get(f"{API}/inventory/history", timeout=30)
        assert r.status_code == 200, r.text
        for entry in r.json():
            assert entry["branch"] == "PLAZA TOYOTA KYAI TAPA"

    def test_delete_manager_forbidden(self):
        s = requests.Session()
        _login(s, MANAGER)
        r = s.delete(f"{API}/inventory", params={"all_data": "true"}, timeout=30)
        assert r.status_code == 403, r.text

    def test_delete_batch_by_upload_date_prefix(self):
        s = requests.Session()
        _login(s, ADMIN)
        # upload a batch
        self._upload_batch(s, prefix="DELB")
        # find in history
        hist = s.get(f"{API}/inventory/history", timeout=30).json()
        assert len(hist) > 0
        target = hist[0]
        r = s.delete(f"{API}/inventory", params={
            "branch": target["branch"],
            "upload_date_prefix": target["upload_date"]
        }, timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["deleted_count"] >= 1
        assert data["deleted_count"] == target["count"], f"Expected {target['count']} but deleted {data['deleted_count']}"

    def test_delete_partman_restricted_to_own_branch(self):
        # Admin uploads batch to TENDEAN branch
        s_admin = requests.Session(); _login(s_admin, ADMIN)
        self._upload_batch(s_admin, branch="PLAZA TOYOTA TENDEAN", prefix="TND")
        # partman tries to delete tendean branch data
        s = requests.Session(); _login(s, PARTMAN)
        # Partman forcing branch=TENDEAN should still be scoped to their own branch (KYAI TAPA)
        r = s.delete(f"{API}/inventory", params={"branch": "PLAZA TOYOTA TENDEAN"}, timeout=30)
        assert r.status_code == 200, r.text
        # Now confirm TENDEAN data still exists (was NOT deleted by partman)
        r2 = s_admin.get(f"{API}/inventory", params={"branch": "PLAZA TOYOTA TENDEAN", "limit": 100}, timeout=30)
        assert r2.status_code == 200
        tnd_products = [i["product_number"] for i in r2.json()["items"]]
        assert any(p.startswith("TND-") for p in tnd_products), "Partman should NOT be able to delete other branch data"
        # cleanup TENDEAN
        s_admin.delete(f"{API}/inventory", params={"branch": "PLAZA TOYOTA TENDEAN"}, timeout=30)

    def test_delete_all_admin(self):
        s = requests.Session()
        _login(s, ADMIN)
        # Upload something first
        self._upload_batch(s, prefix="DELALL")
        # Verify data exists
        before = s.get(f"{API}/dashboard/stats", timeout=30).json()["total_parts"]
        assert before > 0
        # Delete all
        r = s.delete(f"{API}/inventory", params={"all_data": "true"}, timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["deleted_count"] == before
        # Verify empty
        after = s.get(f"{API}/dashboard/stats", timeout=30).json()["total_parts"]
        assert after == 0, f"Expected 0 after delete-all, got {after}"

    def test_delete_admin_missing_params_returns_400(self):
        s = requests.Session()
        _login(s, ADMIN)
        r = s.delete(f"{API}/inventory", timeout=30)
        assert r.status_code == 400, r.text


# ---------------- MIP CALIBRATED MULTIPLIERS ----------------
class TestMIPCalibratedMultipliers:
    def test_multipliers_are_calibrated(self):
        import sys
        sys.path.insert(0, "/app/backend")
        from mip_calculator import calculate_mip_for_part
        # FMV: freq=4 -> multiplier 1.0
        r_fmv = calculate_mip_for_part({"mar_demand": 5, "apr_demand": 5, "mei_demand": 5, "jun_demand": 5})
        assert r_fmv["stock_status"] == "FMV"
        assert r_fmv["safety_stock_factor"] == 1.0
        # MMV: freq=2
        r_mmv = calculate_mip_for_part({"mar_demand": 5, "apr_demand": 5, "mei_demand": 0, "jun_demand": 0})
        assert r_mmv["stock_status"] == "MMV"
        assert r_mmv["safety_stock_factor"] == 1.3
        # SMV: freq=1
        r_smv = calculate_mip_for_part({"mar_demand": 5, "apr_demand": 0, "mei_demand": 0, "jun_demand": 0})
        assert r_smv["stock_status"] == "SMV"
        assert r_smv["safety_stock_factor"] == 2.0
        # NMV via just one month? freq==1 = SMV. For NMV need freq=0 -> stop order path
        # Verify NMV multiplier value in code branch: use a non-zero freq that maps? No, NMV only when freq=0
        # So verify code constant
        import mip_calculator as m
        # inspect module source to ensure 3.0 appears
        with open(m.__file__) as f:
            src = f.read()
        assert '"nmv_multiplier": 3.0' in src, "NMV multiplier should be 3.0"
