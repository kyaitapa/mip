from dotenv import load_dotenv
from pathlib import Path
import os

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

from fastapi import FastAPI, APIRouter, HTTPException, Request, Response, UploadFile, File, Depends
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional
import logging
from datetime import datetime, timezone, timedelta
from bson import ObjectId
import secrets
import uuid
import io
from openpyxl import load_workbook, Workbook
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
import auth
from mip_calculator import calculate_mip_for_part, recalculate_soq, DEFAULT_PARAMS

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

app = FastAPI()
api_router = APIRouter(prefix="/api")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    name: str
    role: str
    branch: Optional[str] = None

class UserResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    email: str
    name: str
    role: str
    branch: Optional[str] = None
    created_at: datetime

class BranchCreate(BaseModel):
    name: str
    code: str

class BranchResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    name: str
    code: str
    created_at: datetime

class InventoryItemResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    branch: str
    product_number: str
    product_description: str
    qty_on_hand: float
    qty_on_order: float
    unit_cost: float
    mar_demand: float
    apr_demand: float
    mei_demand: float
    jun_demand: float
    avg_demand: float
    max_demand: float
    frequency: int
    mad: float
    stock_status: str
    mip: float
    soq: float
    status: str
    action: str
    stock_month: float
    upload_date: datetime

class NotificationResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    user_id: str
    message: str
    read_status: bool
    created_at: datetime

async def seed_data():
    await db.users.create_index("email", unique=True)
    await db.branches.create_index("code", unique=True)
    await db.login_attempts.create_index("identifier")
    
    admin_email = os.environ.get("ADMIN_EMAIL", "admin@toyota.com")
    admin_password = os.environ.get("ADMIN_PASSWORD", "Admin123!@#")
    existing_admin = await db.users.find_one({"email": admin_email})
    
    if existing_admin is None:
        hashed = auth.hash_password(admin_password)
        await db.users.insert_one({
            "email": admin_email,
            "password_hash": hashed,
            "name": "Admin",
            "role": "admin",
            "created_at": datetime.now(timezone.utc)
        })
        logger.info(f"Admin user created: {admin_email}")
    elif not auth.verify_password(admin_password, existing_admin["password_hash"]):
        await db.users.update_one(
            {"email": admin_email},
            {"$set": {"password_hash": auth.hash_password(admin_password)}}
        )
        logger.info("Admin password updated")
    
    test_users = [
        {"email": "manager@toyota.com", "password": "Manager123!", "name": "Manager Test", "role": "manager", "branch": "PLAZA TOYOTA KYAI TAPA"},
        {"email": "partman@toyota.com", "password": "Partman123!", "name": "Partman Test", "role": "partman", "branch": "PLAZA TOYOTA KYAI TAPA"}
    ]
    
    for user_data in test_users:
        existing = await db.users.find_one({"email": user_data["email"]})
        if not existing:
            hashed = auth.hash_password(user_data["password"])
            await db.users.insert_one({
                "email": user_data["email"],
                "password_hash": hashed,
                "name": user_data["name"],
                "role": user_data["role"],
                "branch": user_data.get("branch"),
                "created_at": datetime.now(timezone.utc)
            })
            logger.info(f"Test user created: {user_data['email']}")
    
    branches = [
        {"name": "PLAZA TOYOTA KYAI TAPA", "code": "KYAI_TAPA"},
        {"name": "PLAZA TOYOTA TENDEAN", "code": "TENDEAN"},
        {"name": "PLAZA TOYOTA PEMUDA", "code": "PEMUDA"},
        {"name": "PLAZA TOYOTA GREEN GARDEN", "code": "GREEN_GARDEN"},
        {"name": "PLAZA TOYOTA GADING SERPONG", "code": "GADING_SERPONG"},
        {"name": "PLAZA TOYOTA BANDUNG", "code": "BANDUNG"}
    ]
    
    # Migrate old branch name if exists
    old_name = "PLAZA TOYOTA KYAI TAPA GADING SERPONG"
    new_name = "PLAZA TOYOTA GADING SERPONG"
    await db.branches.delete_one({"name": old_name})
    await db.users.update_many({"branch": old_name}, {"$set": {"branch": new_name}})
    await db.inventory.update_many({"branch": old_name}, {"$set": {"branch": new_name}})
    await db.notifications.update_many({"branch": old_name}, {"$set": {"branch": new_name}})
    await db.parameters.update_many({"branch": old_name}, {"$set": {"branch": new_name}})
    
    for branch_data in branches:
        existing_branch = await db.branches.find_one({"code": branch_data["code"]})
        if not existing_branch:
            await db.branches.insert_one({
                "name": branch_data["name"],
                "code": branch_data["code"],
                "created_at": datetime.now(timezone.utc)
            })
            logger.info(f"Branch created: {branch_data['name']}")

@app.on_event("startup")
async def startup_event():
    await seed_data()
    logger.info("Database seeded successfully")

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()

async def get_current_user_dependency(request: Request):
    return await auth.get_current_user(request, db)

@api_router.post("/auth/register")
async def register(input_data: RegisterRequest, response: Response):
    email = input_data.email.lower()
    existing = await db.users.find_one({"email": email})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    hashed = auth.hash_password(input_data.password)
    user_doc = {
        "email": email,
        "password_hash": hashed,
        "name": input_data.name,
        "role": input_data.role,
        "branch": input_data.branch,
        "created_at": datetime.now(timezone.utc)
    }
    
    result = await db.users.insert_one(user_doc)
    user_id = str(result.inserted_id)
    
    access_token = auth.create_access_token(user_id, email)
    refresh_token = auth.create_refresh_token(user_id)
    
    response.set_cookie(
        key="access_token",
        value=access_token,
        httponly=True,
        secure=False,
        samesite="lax",
        max_age=900,
        path="/"
    )
    response.set_cookie(
        key="refresh_token",
        value=refresh_token,
        httponly=True,
        secure=False,
        samesite="lax",
        max_age=604800,
        path="/"
    )
    
    return {
        "id": user_id,
        "email": email,
        "name": input_data.name,
        "role": input_data.role,
        "branch": input_data.branch,
        "created_at": user_doc["created_at"]
    }

@api_router.post("/auth/login")
async def login(input_data: LoginRequest, request: Request, response: Response):
    email = input_data.email.lower()
    
    identifier = f"{request.client.host}:{email}"
    attempt = await db.login_attempts.find_one({"identifier": identifier})
    
    if attempt and attempt.get("locked_until"):
        if attempt["locked_until"] > datetime.now(timezone.utc):
            raise HTTPException(status_code=429, detail="Too many failed attempts. Try again later.")
    
    user = await db.users.find_one({"email": email})
    if not user or not auth.verify_password(input_data.password, user["password_hash"]):
        failed_count = attempt.get("failed_count", 0) + 1 if attempt else 1
        locked_until = None
        
        if failed_count >= 5:
            locked_until = datetime.now(timezone.utc) + timedelta(minutes=15)
        
        await db.login_attempts.update_one(
            {"identifier": identifier},
            {"$set": {"failed_count": failed_count, "locked_until": locked_until, "last_attempt": datetime.now(timezone.utc)}},
            upsert=True
        )
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    await db.login_attempts.delete_one({"identifier": identifier})
    
    user_id = str(user["_id"])
    access_token = auth.create_access_token(user_id, email)
    refresh_token = auth.create_refresh_token(user_id)
    
    response.set_cookie(
        key="access_token",
        value=access_token,
        httponly=True,
        secure=False,
        samesite="lax",
        max_age=900,
        path="/"
    )
    response.set_cookie(
        key="refresh_token",
        value=refresh_token,
        httponly=True,
        secure=False,
        samesite="lax",
        max_age=604800,
        path="/"
    )
    
    return {
        "id": user_id,
        "email": user["email"],
        "name": user["name"],
        "role": user["role"],
        "branch": user.get("branch"),
        "created_at": user["created_at"]
    }

@api_router.get("/auth/me")
async def get_me(current_user: dict = Depends(get_current_user_dependency)):
    return current_user

@api_router.post("/auth/logout")
async def logout(response: Response):
    response.delete_cookie("access_token", path="/")
    response.delete_cookie("refresh_token", path="/")
    return {"message": "Logged out successfully"}

@api_router.get("/branches")
async def get_branches(current_user: dict = Depends(get_current_user_dependency)):
    branches_list = await db.branches.find({}, {"_id": 0}).to_list(100)
    return branches_list

# ==================== PARAMETERS ====================

async def get_params_for_branch(branch: Optional[str]) -> dict:
    """Get parameters for a branch, fallback to global, fallback to defaults."""
    # Normalize empty string to None
    if branch == "":
        branch = None
    if branch:
        doc = await db.parameters.find_one({"branch": branch}, {"_id": 0})
        if doc:
            doc.pop("branch", None)
            return {**DEFAULT_PARAMS, **doc}
    # Global params (branch=None)
    global_doc = await db.parameters.find_one({"branch": None}, {"_id": 0})
    if global_doc:
        global_doc.pop("branch", None)
        return {**DEFAULT_PARAMS, **global_doc}
    return DEFAULT_PARAMS

class ParametersUpdate(BaseModel):
    working_days: Optional[int] = None
    oc_factor: Optional[float] = None
    avg_lt_factor: Optional[float] = None
    max_lt_factor: Optional[float] = None
    fmv_multiplier: Optional[float] = None
    mmv_multiplier: Optional[float] = None
    smv_multiplier: Optional[float] = None
    nmv_multiplier: Optional[float] = None
    phase_in_threshold: Optional[int] = None
    phase_out_threshold: Optional[int] = None

@api_router.get("/parameters")
async def get_parameters(
    branch: Optional[str] = None,
    current_user: dict = Depends(get_current_user_dependency)
):
    """Get parameters for a branch. If branch=None returns global."""
    if branch == "":
        branch = None
    if current_user["role"] == "partman":
        branch = current_user.get("branch")
    
    params = await get_params_for_branch(branch)
    return {
        "branch": branch,
        "params": params,
        "defaults": DEFAULT_PARAMS
    }

@api_router.put("/parameters")
async def update_parameters(
    updates: ParametersUpdate,
    branch: Optional[str] = None,
    current_user: dict = Depends(get_current_user_dependency)
):
    """Admin can update global or per-branch. Manager can update their branch only."""
    if current_user["role"] not in ["admin", "manager"]:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    # Normalize empty string to None (global)
    if branch == "":
        branch = None
    
    if current_user["role"] == "manager":
        branch = current_user.get("branch")
        if not branch:
            raise HTTPException(status_code=400, detail="Manager has no assigned branch")
    
    update_dict = {k: v for k, v in updates.model_dump().items() if v is not None}
    if not update_dict:
        raise HTTPException(status_code=400, detail="No parameters to update")
    
    update_dict["updated_at"] = datetime.now(timezone.utc)
    update_dict["updated_by"] = current_user["id"]
    
    await db.parameters.update_one(
        {"branch": branch},
        {"$set": update_dict, "$setOnInsert": {"branch": branch, "created_at": datetime.now(timezone.utc)}},
        upsert=True
    )
    
    params = await get_params_for_branch(branch)
    return {"message": "Parameters updated", "branch": branch, "params": params}

@api_router.post("/parameters/reset")
async def reset_parameters(
    branch: Optional[str] = None,
    current_user: dict = Depends(get_current_user_dependency)
):
    """Reset to defaults (removes the override document)."""
    if current_user["role"] not in ["admin", "manager"]:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    if branch == "":
        branch = None
    
    if current_user["role"] == "manager":
        branch = current_user.get("branch")
    
    await db.parameters.delete_one({"branch": branch})
    return {"message": "Parameters reset to defaults", "params": DEFAULT_PARAMS}


@api_router.post("/inventory/upload")
async def upload_inventory(
    file: UploadFile = File(...),
    branch: str = "",
    current_user: dict = Depends(get_current_user_dependency)
):
    if current_user["role"] not in ["admin", "partman"]:
        raise HTTPException(status_code=403, detail="Not authorized to upload")
    
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Only Excel files are supported")
    
    try:
        contents = await file.read()
        wb = load_workbook(filename=io.BytesIO(contents), data_only=True)
        
        # Try to find the sheet with data: INPUT_DATA first (Toyota Excel), then first sheet
        preferred_sheets = ['INPUT_DATA', 'Input_Data', 'input_data', 'Inventory', 'Data']
        ws = None
        for sheet_name in preferred_sheets:
            if sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
                break
        if ws is None:
            ws = wb.active
        
        # Detect header row (search first 15 rows)
        header_row_idx = 1
        header_keywords = ['part number', 'product number', 'parts number']
        for row_idx in range(1, min(16, ws.max_row + 1)):
            row_values = [str(cell.value or '').strip().lower() for cell in ws[row_idx]]
            if any(kw in row_values for kw in header_keywords):
                header_row_idx = row_idx
                break
        
        headers = []
        for cell in ws[header_row_idx]:
            if cell.value:
                headers.append(str(cell.value).strip())
            else:
                headers.append('')
        
        def get_val(row_dict, *aliases, default=0):
            for alias in aliases:
                for key in row_dict:
                    if key and key.strip().lower() == alias.lower():
                        return row_dict[key]
            return default
        
        uploaded_count = 0
        errors = []
        target_branch = branch or current_user.get("branch", "PLAZA TOYOTA KYAI TAPA")
        
        # Load parameters for this branch
        params = await get_params_for_branch(target_branch)
        
        for idx, row in enumerate(ws.iter_rows(min_row=header_row_idx + 1, values_only=True), start=header_row_idx + 1):
            if not any(row):
                continue
            
            try:
                row_dict = {}
                for i, header in enumerate(headers):
                    if i < len(row) and header:
                        row_dict[header] = row[i]
                
                product_number = str(get_val(row_dict, 'Part Number', 'Product Number', 'Parts Number', default='') or '').strip()
                product_description = str(get_val(row_dict, 'Description', 'Product Description', 'Parts Description', default='') or '').strip()
                
                if not product_number or product_number.lower() in ('none', 'nan', ''):
                    continue
                
                qty_on_hand = float(get_val(row_dict, 'On Hand', 'Qty on Hand', 'Qty On Hand', 'Qty on hand', default=0) or 0)
                qty_on_order = float(get_val(row_dict, 'On Order', 'Qty on Order', 'Qty On Order', default=0) or 0)
                unit_cost = float(get_val(row_dict, 'Price', 'Price List', 'Unit Cost', default=0) or 0)
                location = str(get_val(row_dict, 'Location', default='') or '').strip()
                
                part_data = {
                    "branch": target_branch,
                    "product_number": product_number,
                    "product_description": product_description,
                    "location": location,
                    "qty_on_hand": qty_on_hand,
                    "qty_on_order": qty_on_order,
                    "unit_cost": unit_cost,
                    "mar_demand": float(get_val(row_dict, 'Mar', default=0) or 0),
                    "apr_demand": float(get_val(row_dict, 'Apr', default=0) or 0),
                    "mei_demand": float(get_val(row_dict, 'Mei', 'May', default=0) or 0),
                    "jun_demand": float(get_val(row_dict, 'Jun', 'June', default=0) or 0),
                    "upload_date": datetime.now(timezone.utc),
                    "uploaded_by": current_user["id"]
                }
                
                calculation_result = calculate_mip_for_part(part_data, params)
                part_data.update(calculation_result)
                
                await db.inventory.insert_one(part_data)
                uploaded_count += 1
                
                if part_data["status"] == "Perlu Order":
                    managers = await db.users.find({
                        "role": {"$in": ["manager", "admin"]},
                        "branch": part_data["branch"]
                    }).to_list(100)
                    
                    for manager in managers:
                        await db.notifications.insert_one({
                            "id": str(uuid.uuid4()),
                            "user_id": str(manager["_id"]),
                            "message": f"Part {part_data['product_number']} ({part_data['product_description']}) perlu order {part_data['soq']} unit",
                            "read_status": False,
                            "created_at": datetime.now(timezone.utc),
                            "branch": part_data["branch"]
                        })
                
            except Exception as e:
                errors.append(f"Row {idx}: {str(e)}")
                continue
        
        return {
            "message": f"Successfully uploaded {uploaded_count} items",
            "uploaded_count": uploaded_count,
            "errors": errors[:10] if errors else []
        }
    
    except Exception as e:
        logger.error(f"Upload error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")

@api_router.get("/inventory")
async def get_inventory(
    branch: Optional[str] = None,
    status: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    current_user: dict = Depends(get_current_user_dependency)
):
    query = {}
    
    if current_user["role"] == "partman":
        query["branch"] = current_user.get("branch")
    elif branch:
        query["branch"] = branch
    
    if status:
        query["status"] = status
    
    items = await db.inventory.find(query, {"_id": 0}).sort("upload_date", -1).skip(skip).limit(limit).to_list(limit)
    total = await db.inventory.count_documents(query)
    
    return {"items": items, "total": total}

@api_router.get("/inventory/history")
async def get_upload_history(
    current_user: dict = Depends(get_current_user_dependency)
):
    """Get list of upload batches grouped by upload date & branch"""
    query = {}
    if current_user["role"] == "partman":
        query["branch"] = current_user.get("branch")
    
    pipeline = [
        {"$match": query},
        {"$group": {
            "_id": {
                "branch": "$branch",
                "upload_date": {"$dateToString": {"format": "%Y-%m-%d %H:%M", "date": "$upload_date"}}
            },
            "count": {"$sum": 1},
            "perlu_order_count": {
                "$sum": {"$cond": [{"$eq": ["$status", "Perlu Order"]}, 1, 0]}
            },
            "first_upload": {"$min": "$upload_date"}
        }},
        {"$sort": {"first_upload": -1}},
        {"$limit": 100}
    ]
    
    result = await db.inventory.aggregate(pipeline).to_list(100)
    
    history = []
    for r in result:
        history.append({
            "branch": r["_id"]["branch"],
            "upload_date": r["_id"]["upload_date"],
            "count": r["count"],
            "perlu_order_count": r["perlu_order_count"],
            "first_upload": r["first_upload"].isoformat() if r.get("first_upload") else None
        })
    return history

@api_router.delete("/inventory")
async def delete_inventory(
    branch: Optional[str] = None,
    upload_date_prefix: Optional[str] = None,
    all_data: bool = False,
    current_user: dict = Depends(get_current_user_dependency)
):
    """Delete inventory data. Admin can delete all. Partman only their branch."""
    if current_user["role"] not in ["admin", "partman"]:
        raise HTTPException(status_code=403, detail="Not authorized to delete")
    
    query = {}
    
    if current_user["role"] == "partman":
        # Partman can only delete their branch data
        query["branch"] = current_user.get("branch")
    elif branch:
        query["branch"] = branch
    
    if upload_date_prefix:
        try:
            from datetime import datetime as dt
            start_dt = dt.strptime(upload_date_prefix, "%Y-%m-%d %H:%M")
            end_dt = start_dt + timedelta(minutes=1)
            query["upload_date"] = {"$gte": start_dt.replace(tzinfo=timezone.utc), "$lt": end_dt.replace(tzinfo=timezone.utc)}
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Invalid date format: {str(e)}")
    
    if not all_data and not query and current_user["role"] == "admin":
        raise HTTPException(status_code=400, detail="Must specify branch, upload_date_prefix, or all_data=true")
    
    result = await db.inventory.delete_many(query)
    
    # Also cleanup notifications
    if current_user["role"] == "admin" and all_data:
        await db.notifications.delete_many({})
    
    return {
        "message": f"Deleted {result.deleted_count} items",
        "deleted_count": result.deleted_count
    }



@api_router.get("/dashboard/stats")
async def get_dashboard_stats(
    branch: Optional[str] = None,
    current_user: dict = Depends(get_current_user_dependency)
):
    query = {}
    if current_user["role"] == "partman":
        query["branch"] = current_user.get("branch")
    elif branch:
        query["branch"] = branch
    
    total_parts = await db.inventory.count_documents(query)
    
    perlu_order = await db.inventory.count_documents({**query, "status": "Perlu Order"})
    over_stok = await db.inventory.count_documents({**query, "status": "Over Stok"})
    normal = await db.inventory.count_documents({**query, "status": "Normal"})
    stop_order = await db.inventory.count_documents({**query, "status": "Stop Order"})
    
    pipeline = [
        {"$match": query},
        {"$group": {
            "_id": "$stock_status",
            "count": {"$sum": 1}
        }}
    ]
    stock_status_dist = await db.inventory.aggregate(pipeline).to_list(100)
    
    return {
        "total_parts": total_parts,
        "perlu_order": perlu_order,
        "over_stok": over_stok,
        "normal": normal,
        "stop_order": stop_order,
        "stock_status_distribution": stock_status_dist
    }

# ==================== DASHBOARD MIP ====================

@api_router.get("/dashboard/mip")
async def get_mip_dashboard(
    branch: Optional[str] = None,
    current_user: dict = Depends(get_current_user_dependency)
):
    """MIP Dashboard: Phase In/Out summary, cost breakdown, gross overstock cost."""
    query = {}
    if current_user["role"] == "partman":
        query["branch"] = current_user.get("branch")
    elif branch:
        query["branch"] = branch
    
    total_parts = await db.inventory.count_documents(query)
    phase_in_count = await db.inventory.count_documents({**query, "phase": "Phase In"})
    phase_out_count = await db.inventory.count_documents({**query, "phase": "Phase Out"})
    neutral_count = await db.inventory.count_documents({**query, "phase": "Neutral"})
    
    # Aggregate cost sums
    cost_agg = await db.inventory.aggregate([
        {"$match": query},
        {"$group": {
            "_id": None,
            "total_gross_cost": {"$sum": "$gross_cost"},
            "total_over_stok_cost": {"$sum": "$over_stok_cost"},
        }}
    ]).to_list(1)
    
    total_gross = cost_agg[0]["total_gross_cost"] if cost_agg else 0
    total_over_stok = cost_agg[0]["total_over_stok_cost"] if cost_agg else 0
    
    # Cost per phase
    phase_cost_agg = await db.inventory.aggregate([
        {"$match": query},
        {"$group": {
            "_id": "$phase",
            "count": {"$sum": 1},
            "gross_cost": {"$sum": "$gross_cost"},
            "over_stok_cost": {"$sum": "$over_stok_cost"}
        }}
    ]).to_list(10)
    
    # Stock status distribution
    stock_status_agg = await db.inventory.aggregate([
        {"$match": query},
        {"$group": {"_id": "$stock_status", "count": {"$sum": 1}}}
    ]).to_list(10)
    
    return {
        "total_parts": total_parts,
        "phase_in_count": phase_in_count,
        "phase_out_count": phase_out_count,
        "neutral_count": neutral_count,
        "total_gross_cost": round(total_gross, 2),
        "total_over_stok_cost": round(total_over_stok, 2),
        "phase_breakdown": [
            {"phase": p["_id"], "count": p["count"],
             "gross_cost": round(p["gross_cost"], 2),
             "over_stok_cost": round(p["over_stok_cost"], 2)}
            for p in phase_cost_agg
        ],
        "stock_status_distribution": stock_status_agg,
    }


# ==================== DASHBOARD SOQ ====================

@api_router.get("/dashboard/soq")
async def get_soq_dashboard(
    branch: Optional[str] = None,
    current_user: dict = Depends(get_current_user_dependency)
):
    """SOQ Dashboard: parts needing order + cost, overstock cost."""
    query = {}
    if current_user["role"] == "partman":
        query["branch"] = current_user.get("branch")
    elif branch:
        query["branch"] = branch
    
    perlu_order = await db.inventory.count_documents({**query, "status": "Perlu Order"})
    over_stok = await db.inventory.count_documents({**query, "status": "Over Stok"})
    normal = await db.inventory.count_documents({**query, "status": "Normal"})
    stop_order = await db.inventory.count_documents({**query, "status": "Stop Order"})
    
    # Perlu Order aggregation: total units to order, total cost
    perlu_order_agg = await db.inventory.aggregate([
        {"$match": {**query, "status": "Perlu Order"}},
        {"$group": {
            "_id": None,
            "total_soq_units": {"$sum": "$soq"},
            "total_order_cost": {"$sum": {"$multiply": ["$soq", "$unit_cost"]}}
        }}
    ]).to_list(1)
    
    order_units = perlu_order_agg[0]["total_soq_units"] if perlu_order_agg else 0
    order_cost = perlu_order_agg[0]["total_order_cost"] if perlu_order_agg else 0
    
    # Over Stok aggregation
    overstock_agg = await db.inventory.aggregate([
        {"$match": {**query, "status": "Over Stok"}},
        {"$group": {
            "_id": None,
            "total_over_units": {"$sum": {"$subtract": ["$qty_on_hand", "$mip"]}},
            "total_over_cost": {"$sum": "$over_stok_cost"}
        }}
    ]).to_list(1)
    
    over_units = overstock_agg[0]["total_over_units"] if overstock_agg else 0
    over_cost = overstock_agg[0]["total_over_cost"] if overstock_agg else 0
    
    # Top 10 parts perlu order (by cost)
    top_perlu_order = await db.inventory.find(
        {**query, "status": "Perlu Order"},
        {"_id": 0, "product_number": 1, "product_description": 1, "soq": 1, "unit_cost": 1, "qty_on_hand": 1, "mip": 1}
    ).sort([("unit_cost", -1), ("soq", -1)]).limit(10).to_list(10)
    
    for item in top_perlu_order:
        item["order_cost"] = round(item.get("soq", 0) * item.get("unit_cost", 0), 2)
    
    return {
        "perlu_order_count": perlu_order,
        "over_stok_count": over_stok,
        "normal_count": normal,
        "stop_order_count": stop_order,
        "total_order_units": round(order_units, 2),
        "total_order_cost": round(order_cost, 2),
        "total_over_units": round(over_units, 2),
        "total_over_cost": round(over_cost, 2),
        "top_perlu_order": top_perlu_order,
    }


# ==================== SOQ UPLOAD (Daily) ====================

@api_router.post("/soq/upload")
async def upload_soq(
    file: UploadFile = File(...),
    branch: str = "",
    current_user: dict = Depends(get_current_user_dependency)
):
    """
    Daily SOQ upload: updates only Qty on Hand and Qty on Order for existing parts,
    then recalculates SOQ using existing MIP value.
    """
    if current_user["role"] not in ["admin", "partman"]:
        raise HTTPException(status_code=403, detail="Not authorized to upload")
    
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Only Excel files are supported")
    
    try:
        contents = await file.read()
        wb = load_workbook(filename=io.BytesIO(contents), data_only=True)
        
        preferred_sheets = ['SOQ', 'ON_HAND', 'On Hand', 'INPUT_DATA', 'Stok Gudang', 'Inventory']
        ws = None
        for s in preferred_sheets:
            if s in wb.sheetnames:
                ws = wb[s]
                break
        if ws is None:
            ws = wb.active
        
        header_row_idx = 1
        header_keywords = ['part number', 'product number', 'parts number', 'product']
        for row_idx in range(1, min(16, ws.max_row + 1)):
            row_values = [str(cell.value or '').strip().lower() for cell in ws[row_idx]]
            if any(kw in row_values for kw in header_keywords):
                header_row_idx = row_idx
                break
        
        headers = []
        for cell in ws[header_row_idx]:
            headers.append(str(cell.value).strip() if cell.value else '')
        
        def get_val(row_dict, *aliases, default=0):
            for alias in aliases:
                for key in row_dict:
                    if key and key.strip().lower() == alias.lower():
                        return row_dict[key]
            return default
        
        target_branch = branch or current_user.get("branch", "")
        if not target_branch:
            raise HTTPException(status_code=400, detail="Branch required")
        
        updated_count = 0
        not_found_count = 0
        errors = []
        
        for idx, row in enumerate(ws.iter_rows(min_row=header_row_idx + 1, values_only=True), start=header_row_idx + 1):
            if not any(row):
                continue
            try:
                row_dict = {}
                for i, header in enumerate(headers):
                    if i < len(row) and header:
                        row_dict[header] = row[i]
                
                product_number = str(get_val(row_dict, 'Part Number', 'Product Number', 'Parts Number', 'Product', default='') or '').strip()
                if not product_number or product_number.lower() in ('none', 'nan', ''):
                    continue
                
                new_qty_on_hand = float(get_val(row_dict, 'On Hand', 'Qty on Hand', 'Qty On Hand', 'Qty on hand', default=0) or 0)
                new_qty_on_order = float(get_val(row_dict, 'On Order', 'Qty on Order', 'Qty On Order', default=None) or 0)
                
                # Find existing MIP record
                existing = await db.inventory.find_one({
                    "branch": target_branch,
                    "product_number": product_number
                }, {"_id": 0})
                
                if not existing:
                    not_found_count += 1
                    continue
                
                # Recalculate SOQ using existing MIP
                mip = existing.get("mip", 0)
                unit_cost = existing.get("unit_cost", 0)
                new_soq = recalculate_soq(mip, new_qty_on_hand, new_qty_on_order)
                
                # Determine new status
                if new_soq > 0:
                    new_status = 'Perlu Order'
                    new_action = f'Order {new_soq} unit'
                elif new_qty_on_hand > (mip * 2) and mip > 0:
                    new_status = 'Over Stok'
                    new_action = '⚠ Over Stok - Tinjau Inventory'
                elif existing.get("frequency", 0) == 0:
                    new_status = 'Stop Order'
                    new_action = '⚠ Stop Order - Tidak Ada Demand'
                else:
                    new_status = 'Normal'
                    new_action = 'Maintain Stock'
                
                # Cost updates
                gross_cost = new_qty_on_hand * unit_cost
                over_stok_cost = max(0, (new_qty_on_hand - mip) * unit_cost) if mip > 0 else 0
                
                await db.inventory.update_one(
                    {"branch": target_branch, "product_number": product_number},
                    {"$set": {
                        "qty_on_hand": new_qty_on_hand,
                        "qty_on_order": new_qty_on_order,
                        "soq": new_soq,
                        "status": new_status,
                        "action": new_action,
                        "gross_cost": round(gross_cost, 2),
                        "over_stok_cost": round(over_stok_cost, 2),
                        "soq_last_update": datetime.now(timezone.utc),
                    }}
                )
                updated_count += 1
                
                if new_status == "Perlu Order":
                    managers = await db.users.find({
                        "role": {"$in": ["manager", "admin"]},
                        "branch": target_branch
                    }).to_list(100)
                    for manager in managers:
                        await db.notifications.insert_one({
                            "id": str(uuid.uuid4()),
                            "user_id": str(manager["_id"]),
                            "message": f"[SOQ Update] {product_number} perlu order {new_soq} unit",
                            "read_status": False,
                            "created_at": datetime.now(timezone.utc),
                            "branch": target_branch
                        })
            except Exception as e:
                errors.append(f"Row {idx}: {str(e)}")
        
        # Log SOQ upload
        await db.soq_uploads.insert_one({
            "id": str(uuid.uuid4()),
            "branch": target_branch,
            "uploaded_by": current_user["id"],
            "uploaded_at": datetime.now(timezone.utc),
            "updated_count": updated_count,
            "not_found_count": not_found_count,
        })
        
        return {
            "message": f"SOQ berhasil di-update untuk {updated_count} parts",
            "updated_count": updated_count,
            "not_found_count": not_found_count,
            "errors": errors[:10]
        }
    except Exception as e:
        logger.error(f"SOQ upload error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")


@api_router.get("/soq/history")
async def get_soq_history(current_user: dict = Depends(get_current_user_dependency)):
    """Get SOQ upload history."""
    query = {}
    if current_user["role"] == "partman":
        query["branch"] = current_user.get("branch")
    
    uploads = await db.soq_uploads.find(query, {"_id": 0}).sort("uploaded_at", -1).limit(50).to_list(50)
    for u in uploads:
        if isinstance(u.get("uploaded_at"), datetime):
            u["uploaded_at"] = u["uploaded_at"].isoformat()
    return uploads



@api_router.get("/notifications")
async def get_notifications(
    current_user: dict = Depends(get_current_user_dependency)
):
    notifications = await db.notifications.find(
        {"user_id": current_user["id"]},
        {"_id": 0}
    ).sort("created_at", -1).limit(50).to_list(50)
    
    return notifications

@api_router.put("/notifications/{notification_id}/read")
async def mark_notification_read(
    notification_id: str,
    current_user: dict = Depends(get_current_user_dependency)
):
    await db.notifications.update_one(
        {"id": notification_id, "user_id": current_user["id"]},
        {"$set": {"read_status": True}}
    )
    return {"message": "Notification marked as read"}

@api_router.get("/export/excel")
async def export_to_excel(
    branch: Optional[str] = None,
    status: Optional[str] = None,
    current_user: dict = Depends(get_current_user_dependency)
):
    query = {}
    if current_user["role"] == "partman":
        query["branch"] = current_user.get("branch")
    elif branch:
        query["branch"] = branch
    
    if status:
        query["status"] = status
    
    items = await db.inventory.find(query, {"_id": 0}).to_list(1000)
    
    wb = Workbook()
    ws = wb.active
    ws.title = "MIP Report"
    
    headers = [
        "Branch", "Product Number", "Product Description", "Qty on Hand", "Qty on Order",
        "Unit Cost", "Mar", "Apr", "Mei", "Jun", "Avg Demand", "Max Demand",
        "Frequency", "MAD", "Stock Status", "MIP", "SOQ", "Status", "Action", "Stock Month"
    ]
    
    ws.append(headers)
    
    for item in items:
        ws.append([
            item.get("branch", ""),
            item.get("product_number", ""),
            item.get("product_description", ""),
            item.get("qty_on_hand", 0),
            item.get("qty_on_order", 0),
            item.get("unit_cost", 0),
            item.get("mar_demand", 0),
            item.get("apr_demand", 0),
            item.get("mei_demand", 0),
            item.get("jun_demand", 0),
            item.get("avg_demand", 0),
            item.get("max_demand", 0),
            item.get("frequency", 0),
            item.get("mad", 0),
            item.get("stock_status", ""),
            item.get("mip", 0),
            item.get("soq", 0),
            item.get("status", ""),
            item.get("action", ""),
            item.get("stock_month", 0)
        ])
    
    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    
    from fastapi.responses import StreamingResponse
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename=mip_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"}
    )

@api_router.get("/export/pdf")
async def export_to_pdf(
    branch: Optional[str] = None,
    status: Optional[str] = None,
    current_user: dict = Depends(get_current_user_dependency)
):
    query = {}
    if current_user["role"] == "partman":
        query["branch"] = current_user.get("branch")
    elif branch:
        query["branch"] = branch
    
    if status:
        query["status"] = status
    
    items = await db.inventory.find(query, {"_id": 0}).limit(500).to_list(500)
    
    output = io.BytesIO()
    doc = SimpleDocTemplate(output, pagesize=landscape(A4), topMargin=30, bottomMargin=30)
    styles = getSampleStyleSheet()
    
    elements = []
    title = Paragraph(f"<b>Toyota MIP Report</b><br/>{datetime.now().strftime('%d %B %Y')}", styles['Title'])
    elements.append(title)
    elements.append(Spacer(1, 12))
    
    if items:
        table_data = [["Part No", "Description", "Branch", "Hand", "Order", "Avg", "Stk", "MIP", "SOQ", "Status"]]
        for item in items:
            table_data.append([
                str(item.get("product_number", ""))[:15],
                str(item.get("product_description", ""))[:25],
                str(item.get("branch", ""))[:15],
                str(item.get("qty_on_hand", 0)),
                str(item.get("qty_on_order", 0)),
                str(item.get("avg_demand", 0)),
                str(item.get("stock_status", "")),
                str(item.get("mip", 0)),
                str(item.get("soq", 0)),
                str(item.get("status", ""))
            ])
        
        t = Table(table_data, repeatRows=1)
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#E60012')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F5F5F5')])
        ]))
        elements.append(t)
    else:
        elements.append(Paragraph("Tidak ada data.", styles['Normal']))
    
    doc.build(elements)
    output.seek(0)
    
    from fastapi.responses import StreamingResponse
    return StreamingResponse(
        output,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=mip_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"}
    )

@api_router.get("/users")
async def get_users(current_user: dict = Depends(get_current_user_dependency)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Not authorized")
    
    users = await db.users.find({}, {"password_hash": 0, "_id": 0}).to_list(100)
    return users

app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)
