export const formatIDR = (amount) => {
  if (amount == null || isNaN(amount)) return 'Rp 0';
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
};

export const formatIDRShort = (amount) => {
  if (amount == null || isNaN(amount)) return 'Rp 0';
  const abs = Math.abs(amount);
  if (abs >= 1_000_000_000) return `Rp ${(amount / 1_000_000_000).toFixed(1)}M`;
  if (abs >= 1_000_000) return `Rp ${(amount / 1_000_000).toFixed(1)}Jt`;
  if (abs >= 1_000) return `Rp ${(amount / 1_000).toFixed(1)}rb`;
  return `Rp ${amount.toFixed(0)}`;
};

export const formatNumber = (n) => {
  if (n == null || isNaN(n)) return '0';
  return new Intl.NumberFormat('id-ID').format(n);
};
