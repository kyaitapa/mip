import React, { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { userAPI } from '../utils/api';
import { Users as UsersIcon } from '@phosphor-icons/react';

export function Users() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const response = await userAPI.getAll();
      setUsers(response.data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const roleColors = {
    admin: 'bg-red-500/10 text-red-700',
    manager: 'bg-blue-500/10 text-blue-700',
    partman: 'bg-green-500/10 text-green-700'
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">Administration</p>
          <h1 className="text-3xl lg:text-4xl font-bold tracking-tight">Kelola User</h1>
          <p className="text-muted-foreground mt-1">Total: {users.length} user</p>
        </div>

        <Card className="border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UsersIcon size={20} weight="fill" />
              Daftar User
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 border-b border-border">
                  <tr>
                    <th className="text-left px-4 py-3 font-semibold uppercase text-xs tracking-wider">Nama</th>
                    <th className="text-left px-4 py-3 font-semibold uppercase text-xs tracking-wider">Email</th>
                    <th className="text-left px-4 py-3 font-semibold uppercase text-xs tracking-wider">Role</th>
                    <th className="text-left px-4 py-3 font-semibold uppercase text-xs tracking-wider">Cabang</th>
                    <th className="text-left px-4 py-3 font-semibold uppercase text-xs tracking-wider">Dibuat</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan={5} className="text-center py-16 text-muted-foreground">Loading...</td>
                    </tr>
                  ) : users.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="text-center py-16 text-muted-foreground">Belum ada user</td>
                    </tr>
                  ) : (
                    users.map((u, idx) => (
                      <tr key={idx} className="border-b border-border hover:bg-accent/50 transition-colors" data-testid={`user-row-${idx}`}>
                        <td className="px-4 py-3 font-medium">{u.name}</td>
                        <td className="px-4 py-3">{u.email}</td>
                        <td className="px-4 py-3">
                          <span className={`inline-block px-2 py-0.5 rounded text-xs font-medium uppercase ${roleColors[u.role] || 'bg-gray-500/10'}`}>
                            {u.role}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-muted-foreground">{u.branch || '-'}</td>
                        <td className="px-4 py-3 text-xs text-muted-foreground">
                          {u.created_at ? new Date(u.created_at).toLocaleDateString('id-ID') : '-'}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
