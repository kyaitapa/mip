"""
Toyota MIP Calculator - Configurable
Based on Toyota's Inventory Control Formula:
- MIP = Avg.Dmd × (O/C + Avg.L/T + SS_lt + SS_dmd)
- SOQ = MIP - (Qty on Hand + Qty on Order) + Back Order
- Phase In = permintaan > 3 kali dalam bulan berbeda
- Phase Out = permintaan < 2 kali dalam bulan berbeda
"""
from typing import Dict, Any, Optional

# Default parameters (from Toyota PARAMETER sheet)
DEFAULT_PARAMS = {
    "working_days": 22,
    "oc_factor": 1,
    "avg_lt_factor": 2,
    "max_lt_factor": 6,
    "fmv_multiplier": 1.0,
    "mmv_multiplier": 1.3,
    "smv_multiplier": 2.0,
    "nmv_multiplier": 3.0,
    # Classification thresholds (frequency in 4 months)
    "phase_in_threshold": 3,   # freq >= this = Phase In
    "phase_out_threshold": 2,  # freq < this = Phase Out
}


def get_stock_status(frequency: int) -> str:
    """Classify FMV/MMV/SMV/NMV based on frequency (months with demand)"""
    if frequency >= 3:
        return 'FMV'
    elif frequency == 2:
        return 'MMV'
    elif frequency == 1:
        return 'SMV'
    else:
        return 'NMV'


def get_phase(frequency: int, params: Dict) -> str:
    """
    Get Phase In / Phase Out / Neutral based on Excel formula.
    Phase In = permintaan >= 3 kali dalam bulan berbeda
    Phase Out = permintaan < 2 kali dalam bulan berbeda
    """
    phase_in_th = params.get("phase_in_threshold", 3)
    phase_out_th = params.get("phase_out_threshold", 2)
    
    if frequency >= phase_in_th:
        return 'Phase In'
    elif frequency < phase_out_th:
        return 'Phase Out'
    else:
        return 'Neutral'


def calculate_mip_for_part(part_data: Dict[str, Any], params: Optional[Dict] = None) -> Dict[str, Any]:
    """Calculate MIP for a Toyota part with configurable parameters."""
    if params is None:
        params = DEFAULT_PARAMS
    
    # Merge with defaults
    p = {**DEFAULT_PARAMS, **params}
    
    try:
        demand_list = [
            float(part_data.get('mar_demand', 0) or 0),
            float(part_data.get('apr_demand', 0) or 0),
            float(part_data.get('mei_demand', 0) or 0),
            float(part_data.get('jun_demand', 0) or 0),
        ]

        qty_on_hand = float(part_data.get('qty_on_hand', 0) or 0)
        qty_on_order = float(part_data.get('qty_on_order', 0) or 0)
        back_order = float(part_data.get('back_order', 0) or 0)
        unit_cost = float(part_data.get('unit_cost', 0) or 0)

        frequency = sum(1 for d in demand_list if d > 0)

        # Compute derived ratios from params
        working_days = p["working_days"]
        oc_total = p["oc_factor"] / working_days
        avg_lt_total = p["avg_lt_factor"] / working_days
        max_lt_total = p["max_lt_factor"] / working_days

        stock_status = get_stock_status(frequency)
        phase = get_phase(frequency, p)

        if frequency == 0:
            gross_cost = qty_on_hand * unit_cost
            return {
                'avg_demand': 0.0,
                'max_demand': 0.0,
                'frequency': 0,
                'mad': 0.0,
                'stock_status': stock_status,
                'phase': phase,
                'safety_stock_factor': 0.0,
                'ss_lt': 0.0,
                'ss_dmd': 0.0,
                'total_factor_ss': 0.0,
                'mip': 0,
                'soq': 0,
                'status': 'Stop Order',
                'action': '⚠ Stop Order - Tidak Ada Demand',
                'stock_month': 0.0,
                'gross_cost': round(gross_cost, 2),
                'over_stok_cost': round(gross_cost, 2),  # all overstock if no demand
            }

        avg_demand = sum(demand_list) / 4.0
        max_demand = max(demand_list)

        # MAD (annualized demand indicator)
        total_demand = sum(demand_list)
        mad = total_demand * (52.0 / 17.0)

        # SS L/T & SS Dmd ratios
        ss_lt = (max_lt_total - avg_lt_total) / avg_lt_total if avg_lt_total > 0 else 0
        ss_dmd = (max_demand - avg_demand) / avg_demand if avg_demand > 0 else 0

        # Safety Stock multiplier by stock status
        if stock_status == 'FMV':
            ss_multiplier = p["fmv_multiplier"]
        elif stock_status == 'MMV':
            ss_multiplier = p["mmv_multiplier"]
        elif stock_status == 'SMV':
            ss_multiplier = p["smv_multiplier"]
        else:
            ss_multiplier = p["nmv_multiplier"]

        ss_lt_scaled = ss_lt * avg_lt_total * ss_multiplier
        ss_dmd_scaled = ss_dmd * avg_lt_total * ss_multiplier

        total_factor_ss = oc_total + avg_lt_total + ss_lt_scaled + ss_dmd_scaled

        mip = round(max(0, avg_demand * total_factor_ss))

        # SOQ = MIP - (O/H + O/O) + B/O
        soq_raw = mip - (qty_on_hand + qty_on_order) + back_order
        soq = max(0, round(soq_raw))

        stock_month = (qty_on_hand / avg_demand) if avg_demand > 0 else 0

        # Cost calculations
        gross_cost = qty_on_hand * unit_cost
        over_stok_cost = max(0, (qty_on_hand - mip) * unit_cost) if mip > 0 else 0

        if soq > 0:
            status = 'Perlu Order'
            action = f'Order {soq} unit'
        elif qty_on_hand > (mip * 2) and mip > 0:
            status = 'Over Stok'
            action = '⚠ Over Stok - Tinjau Inventory'
        else:
            status = 'Normal'
            action = 'Maintain Stock'

        return {
            'avg_demand': round(avg_demand, 2),
            'max_demand': round(max_demand, 2),
            'frequency': frequency,
            'mad': round(mad, 2),
            'stock_status': stock_status,
            'phase': phase,
            'safety_stock_factor': ss_multiplier,
            'ss_lt': round(ss_lt_scaled, 4),
            'ss_dmd': round(ss_dmd_scaled, 4),
            'total_factor_ss': round(total_factor_ss, 4),
            'mip': mip,
            'soq': soq,
            'status': status,
            'action': action,
            'stock_month': round(stock_month, 2),
            'gross_cost': round(gross_cost, 2),
            'over_stok_cost': round(over_stok_cost, 2),
        }
    except Exception as e:
        return {
            'avg_demand': 0, 'max_demand': 0, 'frequency': 0, 'mad': 0,
            'stock_status': 'ERROR', 'phase': 'Unknown', 'safety_stock_factor': 0,
            'ss_lt': 0, 'ss_dmd': 0, 'total_factor_ss': 0,
            'mip': 0, 'soq': 0, 'status': 'Error', 'action': f'Error: {str(e)}',
            'stock_month': 0, 'gross_cost': 0, 'over_stok_cost': 0,
        }


def recalculate_soq(mip: int, qty_on_hand: float, qty_on_order: float, back_order: float = 0) -> int:
    """Recalculate only SOQ when on-hand changes (daily upload)."""
    return max(0, round(mip - (qty_on_hand + qty_on_order) + back_order))
