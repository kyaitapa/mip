import React, { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { dashboardAPI, branchAPI } from '../utils/api';
import { formatIDR, formatIDRShort, formatNumber } from '../utils/format';
import { ShoppingCart, ArrowUp, CheckCircle, XCircle, Warning, CurrencyDollar } from '@phosphor-icons/react';

export function DashboardSOQ() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [branches, setBranches] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState('all');

  useEffect(() => { loadBranches(); }, []);
  useEffect(() => { loadStats(); }, [selectedBranch]);

  const loadBranches = async () => {
    try {
      const r = await branchAPI.getAll();
      setBranches(r.data);
    } catch (e) { console.error(e); }
  };

  const loadStats = async () => {
    try {
      const branch = selectedBranch === 'all' ? '' : selectedBranch;
      const r = await dashboardAPI.getSOQStats(branch);
      setStats(r.data);
    } catch (e) { console.error(e); }
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">Daily Update</p>
            <h1 className="text-3xl lg:text-4xl font-bold tracking-tight">Dashboard SOQ</h1>
            <p className="text-muted-foreground mt-1">Standard Order Quantity — kebutuhan order harian</p>
          </div>
          {user?.role !== 'partman' && (
            <Select value={selectedBranch} onValueChange={setSelectedBranch}>
              <SelectTrigger className="w-full sm:w-64" data-testid="branch-filter">
                <SelectValue placeholder="Pilih Cabang" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Cabang</SelectItem>
                {branches.map(b => <SelectItem key={b.code} value={b.name}>{b.name}</SelectItem>)}
              </SelectContent>
            </Select>
          )}
        </div>

        {/* Highlighted Order/Overstock Costs */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="border-border border-l-4 border-l-red-500 hover:-translate-y-1 transition-transform">
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <p className="text-xs uppercase tracking-[0.15em] text-red-700 font-semibold">Perlu Order</p>
                  <p className="text-2xl font-bold mt-2 tracking-tight text-red-700" data-testid="soq-total-order-cost">
                    {formatIDR(stats?.total_order_cost || 0)}
                  </p>
                  <div className="grid grid-cols-2 gap-4 mt-4 pt-4 border-t border-border">
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">Items</p>
                      <p className="text-xl font-bold mt-1" data-testid="soq-perlu-order-count">{formatNumber(stats?.perlu_order_count || 0)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">Total Units</p>
                      <p className="text-xl font-bold mt-1" data-testid="soq-order-units">{formatNumber(stats?.total_order_units || 0)}</p>
                    </div>
                  </div>
                </div>
                <div className="p-3 rounded-md bg-red-500/10">
                  <ShoppingCart size={32} weight="fill" className="text-red-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border border-l-4 border-l-yellow-500 hover:-translate-y-1 transition-transform">
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <p className="text-xs uppercase tracking-[0.15em] text-yellow-700 font-semibold">Over Stok Cost</p>
                  <p className="text-2xl font-bold mt-2 tracking-tight text-yellow-700" data-testid="soq-total-over-cost">
                    {formatIDR(stats?.total_over_cost || 0)}
                  </p>
                  <div className="grid grid-cols-2 gap-4 mt-4 pt-4 border-t border-border">
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">Items</p>
                      <p className="text-xl font-bold mt-1" data-testid="soq-over-stok-count">{formatNumber(stats?.over_stok_count || 0)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">Excess Units</p>
                      <p className="text-xl font-bold mt-1" data-testid="soq-over-units">{formatNumber(stats?.total_over_units || 0)}</p>
                    </div>
                  </div>
                </div>
                <div className="p-3 rounded-md bg-yellow-500/10">
                  <ArrowUp size={32} weight="fill" className="text-yellow-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="Perlu Order" value={formatNumber(stats?.perlu_order_count || 0)} icon={ShoppingCart} color="bg-red-500/10 text-red-600" />
          <StatCard title="Over Stok" value={formatNumber(stats?.over_stok_count || 0)} icon={ArrowUp} color="bg-yellow-500/10 text-yellow-600" />
          <StatCard title="Normal" value={formatNumber(stats?.normal_count || 0)} icon={CheckCircle} color="bg-green-500/10 text-green-600" />
          <StatCard title="Stop Order" value={formatNumber(stats?.stop_order_count || 0)} icon={XCircle} color="bg-gray-500/10 text-gray-600" />
        </div>

        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-xl flex items-center gap-2">
              <Warning size={20} weight="fill" className="text-red-600" />
              Top 10 Parts Perlu Order (by Cost)
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 border-b border-border">
                  <tr>
                    <th className="text-left px-4 py-3 font-semibold uppercase text-xs tracking-wider">Part Number</th>
                    <th className="text-left px-4 py-3 font-semibold uppercase text-xs tracking-wider">Deskripsi</th>
                    <th className="text-right px-4 py-3 font-semibold uppercase text-xs tracking-wider">Qty Hand</th>
                    <th className="text-right px-4 py-3 font-semibold uppercase text-xs tracking-wider">MIP</th>
                    <th className="text-right px-4 py-3 font-semibold uppercase text-xs tracking-wider">SOQ</th>
                    <th className="text-right px-4 py-3 font-semibold uppercase text-xs tracking-wider">Price</th>
                    <th className="text-right px-4 py-3 font-semibold uppercase text-xs tracking-wider">Order Cost</th>
                  </tr>
                </thead>
                <tbody>
                  {!stats?.top_perlu_order?.length ? (
                    <tr><td colSpan={7} className="text-center py-16 text-muted-foreground">Tidak ada item yang perlu di-order</td></tr>
                  ) : (
                    stats.top_perlu_order.map((item, i) => (
                      <tr key={i} className="border-b border-border hover:bg-accent/50" data-testid={`top-order-row-${i}`}>
                        <td className="px-4 py-3 font-mono text-xs">{item.product_number}</td>
                        <td className="px-4 py-3">{item.product_description}</td>
                        <td className="px-4 py-3 text-right">{formatNumber(item.qty_on_hand)}</td>
                        <td className="px-4 py-3 text-right font-semibold">{formatNumber(item.mip)}</td>
                        <td className="px-4 py-3 text-right font-bold text-red-600">{formatNumber(item.soq)}</td>
                        <td className="px-4 py-3 text-right font-mono text-xs">{formatIDR(item.unit_cost)}</td>
                        <td className="px-4 py-3 text-right font-mono font-bold">{formatIDR(item.order_cost)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-muted/20">
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">
              <strong>Cara kerja SOQ:</strong> MIP dihitung sekali di awal bulan dari data demand history.
              SOQ diupdate setiap hari berdasarkan data On Hand terbaru dengan formula:
              <span className="font-mono mx-1 text-foreground">SOQ = MIP − (Qty on Hand + Qty on Order) + Back Order</span>
            </p>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}

function StatCard({ title, value, icon: Icon, color }) {
  return (
    <Card className="border-border hover:-translate-y-1 transition-transform duration-200">
      <CardContent className="pt-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground font-medium">{title}</p>
            <p className="text-3xl font-bold mt-2 tracking-tight">{value}</p>
          </div>
          <div className={`p-2 rounded-md ${color}`}>
            <Icon size={24} weight="fill" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
