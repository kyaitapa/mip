import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { soqAPI, branchAPI } from '../utils/api';
import { UploadSimple, FileXls, CheckCircle, Info } from '@phosphor-icons/react';
import { toast } from 'sonner';

export function UploadSOQ() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const [file, setFile] = useState(null);
  const [branches, setBranches] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState(user?.branch || '');
  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState(null);
  const [dragActive, setDragActive] = useState(false);

  useEffect(() => { loadBranches(); }, []);

  const loadBranches = async () => {
    try {
      const r = await branchAPI.getAll();
      setBranches(r.data);
    } catch (e) { console.error(e); }
  };

  const handleFileChange = (f) => {
    if (!f) return;
    if (!f.name.match(/\.(xlsx|xls)$/i)) {
      toast.error('File harus Excel (.xlsx atau .xls)');
      return;
    }
    setFile(f);
    setResult(null);
  };

  const handleDrag = (e) => {
    e.preventDefault(); e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') setDragActive(true);
    else if (e.type === 'dragleave') setDragActive(false);
  };

  const handleDrop = (e) => {
    e.preventDefault(); e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files?.[0]) handleFileChange(e.dataTransfer.files[0]);
  };

  const handleUpload = async () => {
    if (!file) { toast.error('Pilih file terlebih dahulu'); return; }
    if (!selectedBranch && user?.role === 'admin') { toast.error('Pilih cabang'); return; }

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);
      const branch = selectedBranch || user?.branch;
      const r = await soqAPI.upload(formData, branch);
      setResult(r.data);
      toast.success(r.data.message);
    } catch (e) {
      toast.error(e.response?.data?.detail || 'Upload gagal');
    } finally {
      setUploading(false);
    }
  };

  return (
    <Layout>
      <div className="space-y-6 max-w-4xl">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">Daily Update</p>
          <h1 className="text-3xl lg:text-4xl font-bold tracking-tight">Upload SOQ Harian</h1>
          <p className="text-muted-foreground mt-1">Update On Hand & On Order — SOQ akan dihitung otomatis</p>
        </div>

        <Card className="border-border bg-blue-500/5 border-blue-500/30">
          <CardContent className="pt-6">
            <div className="flex gap-3">
              <Info size={24} weight="fill" className="text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-semibold mb-1">Perbedaan Upload MIP dan SOQ</p>
                <p className="text-muted-foreground">
                  <strong>MIP</strong> diupload sekali di awal bulan (dengan data demand Mar/Apr/Mei/Jun).
                  <strong className="ml-2">SOQ</strong> diupload setiap hari dengan data On Hand terbaru — 
                  MIP tidak akan berubah, hanya SOQ yang di-recalculate berdasarkan on hand baru.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardHeader>
            <CardTitle>Format File Excel SOQ</CardTitle>
            <CardDescription>File harus memiliki kolom berikut:</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-sm">
              {['Part Number', 'On Hand', 'On Order (opsional)'].map(col => (
                <div key={col} className="bg-muted/50 px-3 py-2 rounded font-mono text-xs">{col}</div>
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-3">
              Sistem akan match Part Number dengan data MIP yang sudah ada, lalu update on hand & recalculate SOQ.
            </p>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardHeader><CardTitle>Upload File</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {user?.role === 'admin' && (
              <div>
                <label className="text-sm font-medium mb-2 block">Pilih Cabang</label>
                <Select value={selectedBranch} onValueChange={setSelectedBranch}>
                  <SelectTrigger data-testid="soq-branch-select">
                    <SelectValue placeholder="Pilih cabang" />
                  </SelectTrigger>
                  <SelectContent>
                    {branches.map(b => <SelectItem key={b.code} value={b.name}>{b.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div
              onDragEnter={handleDrag} onDragLeave={handleDrag} onDragOver={handleDrag} onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-colors ${dragActive ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'}`}
              data-testid="soq-dropzone"
            >
              <input ref={fileInputRef} type="file" accept=".xlsx,.xls" className="hidden"
                     onChange={(e) => handleFileChange(e.target.files?.[0])} data-testid="soq-file-input" />
              {file ? (
                <div className="flex items-center justify-center gap-3">
                  <FileXls size={48} weight="fill" className="text-green-600" />
                  <div className="text-left">
                    <p className="font-semibold">{file.name}</p>
                    <p className="text-xs text-muted-foreground">{(file.size / 1024).toFixed(2)} KB</p>
                  </div>
                </div>
              ) : (
                <>
                  <UploadSimple size={48} className="mx-auto text-muted-foreground mb-4" />
                  <p className="font-medium">Klik atau drag file ke sini</p>
                  <p className="text-xs text-muted-foreground mt-1">Hanya file .xlsx atau .xls</p>
                </>
              )}
            </div>

            <div className="flex gap-3">
              <Button onClick={handleUpload} disabled={!file || uploading} className="flex-1" data-testid="soq-upload-submit">
                {uploading ? 'Uploading...' : 'Upload SOQ Harian'}
              </Button>
              {file && (
                <Button variant="outline" onClick={() => { setFile(null); setResult(null); }} data-testid="soq-clear-button">Clear</Button>
              )}
            </div>
          </CardContent>
        </Card>

        {result && (
          <Card className="border-border" data-testid="soq-upload-result">
            <CardHeader>
              <div className="flex items-center gap-3">
                <CheckCircle size={24} weight="fill" className="text-green-600" />
                <CardTitle>Upload SOQ Berhasil</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs uppercase text-muted-foreground tracking-wider">Berhasil Update</p>
                  <p className="text-2xl font-bold text-green-600">{result.updated_count}</p>
                </div>
                <div>
                  <p className="text-xs uppercase text-muted-foreground tracking-wider">Part Tidak Ditemukan</p>
                  <p className="text-2xl font-bold text-yellow-600">{result.not_found_count}</p>
                </div>
              </div>
              {result.not_found_count > 0 && (
                <p className="text-xs text-muted-foreground">
                  Part yang tidak ditemukan mungkin belum di-upload di MIP. Upload data MIP terlebih dahulu.
                </p>
              )}
              <Button onClick={() => navigate('/dashboard/soq')} className="mt-3" data-testid="view-soq-dashboard">
                Lihat Dashboard SOQ
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
}
