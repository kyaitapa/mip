import React, { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { parametersAPI, branchAPI } from '../utils/api';
import { Gear, ArrowClockwise, FloppyDisk, Info } from '@phosphor-icons/react';
import { toast } from 'sonner';

const PARAM_META = {
  working_days: { label: 'Working Days', description: 'Hari kerja per bulan (default: 22)', section: 'ordering' },
  oc_factor: { label: 'O/C Factor', description: 'Order Cycle dalam hari (default: 1)', section: 'ordering' },
  avg_lt_factor: { label: 'Avg L/T Factor', description: 'Average Lead Time dalam hari (default: 2)', section: 'ordering' },
  max_lt_factor: { label: 'Max L/T Factor', description: 'Maximum Lead Time dalam hari (default: 6)', section: 'ordering' },
  fmv_multiplier: { label: 'FMV Safety Multiplier', description: 'Multiplier untuk Fast Moving parts (default: 1.0)', section: 'safety' },
  mmv_multiplier: { label: 'MMV Safety Multiplier', description: 'Multiplier untuk Medium Moving parts (default: 1.3)', section: 'safety' },
  smv_multiplier: { label: 'SMV Safety Multiplier', description: 'Multiplier untuk Slow Moving parts (default: 2.0)', section: 'safety' },
  nmv_multiplier: { label: 'NMV Safety Multiplier', description: 'Multiplier untuk Non Moving parts (default: 3.0)', section: 'safety' },
  phase_in_threshold: { label: 'Phase In Threshold', description: 'Frequency ≥ ini = Phase In (default: 3)', section: 'phase' },
  phase_out_threshold: { label: 'Phase Out Threshold', description: 'Frequency < ini = Phase Out (default: 2)', section: 'phase' }
};

export function Parameters() {
  const { user } = useAuth();
  const [params, setParams] = useState({});
  const [defaults, setDefaults] = useState({});
  const [branches, setBranches] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState(user?.role === 'manager' ? user?.branch : 'global');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => { loadBranches(); }, []);
  useEffect(() => { loadParams(); }, [selectedBranch]);

  const loadBranches = async () => {
    try {
      const r = await branchAPI.getAll();
      setBranches(r.data);
    } catch (e) { console.error(e); }
  };

  const loadParams = async () => {
    setLoading(true);
    try {
      const branch = selectedBranch === 'global' ? '' : selectedBranch;
      const r = await parametersAPI.get(branch);
      setParams(r.data.params);
      setDefaults(r.data.defaults);
    } catch (e) {
      toast.error('Gagal memuat parameters');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (key, value) => {
    setParams({ ...params, [key]: value });
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const branch = selectedBranch === 'global' ? '' : selectedBranch;
      // Coerce numeric
      const numericParams = {};
      Object.keys(params).forEach(k => {
        const v = params[k];
        numericParams[k] = typeof v === 'string' ? parseFloat(v) : v;
      });
      await parametersAPI.update(numericParams, branch);
      toast.success('Parameters berhasil disimpan');
      await loadParams();
    } catch (e) {
      toast.error(e.response?.data?.detail || 'Gagal simpan');
    } finally {
      setSaving(false);
    }
  };

  const handleReset = async () => {
    if (!window.confirm('Reset parameters ke default?')) return;
    setSaving(true);
    try {
      const branch = selectedBranch === 'global' ? '' : selectedBranch;
      await parametersAPI.reset(branch);
      toast.success('Parameters reset ke default');
      await loadParams();
    } catch (e) {
      toast.error('Gagal reset');
    } finally {
      setSaving(false);
    }
  };

  const renderSection = (sectionKey, title, icon) => {
    const keys = Object.keys(PARAM_META).filter(k => PARAM_META[k].section === sectionKey);
    return (
      <Card className="border-border" key={sectionKey}>
        <CardHeader>
          <CardTitle className="text-lg">{title}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {keys.map(key => (
            <div key={key} className="grid grid-cols-1 md:grid-cols-3 gap-2 items-start">
              <div>
                <Label htmlFor={key} className="text-sm font-medium">{PARAM_META[key].label}</Label>
                <p className="text-xs text-muted-foreground mt-0.5">{PARAM_META[key].description}</p>
              </div>
              <div className="md:col-span-2 flex items-center gap-3">
                <Input
                  id={key}
                  type="number"
                  step="0.01"
                  value={params[key] ?? ''}
                  onChange={(e) => handleChange(key, e.target.value)}
                  className="flex-1"
                  data-testid={`param-${key}`}
                />
                <span className="text-xs text-muted-foreground w-24 font-mono">
                  Default: {defaults[key]}
                </span>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  };

  return (
    <Layout>
      <div className="space-y-6 max-w-4xl">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">Configuration</p>
            <h1 className="text-3xl lg:text-4xl font-bold tracking-tight">Parameter MIP</h1>
            <p className="text-muted-foreground mt-1">Sesuaikan parameter perhitungan MIP per cabang</p>
          </div>
          <div className="flex items-center gap-2">
            {user?.role === 'admin' && (
              <Select value={selectedBranch} onValueChange={setSelectedBranch}>
                <SelectTrigger className="w-56" data-testid="param-branch-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="global">Global (Default semua cabang)</SelectItem>
                  {branches.map(b => <SelectItem key={b.code} value={b.name}>{b.name}</SelectItem>)}
                </SelectContent>
              </Select>
            )}
          </div>
        </div>

        <Card className="border-border bg-blue-500/5 border-blue-500/30">
          <CardContent className="pt-6">
            <div className="flex gap-3">
              <Info size={24} weight="fill" className="text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-semibold mb-1">Cara Kerja Parameter</p>
                <p className="text-muted-foreground">
                  Parameter dibaca saat upload MIP dilakukan. Jika ada override per cabang, akan pakai itu; 
                  jika tidak, akan pakai global setting; jika keduanya tidak ada, pakai default Toyota. 
                  Perubahan hanya berlaku untuk upload MIP <strong>setelahnya</strong>.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {loading ? (
          <div className="text-center py-16 text-muted-foreground">Loading...</div>
        ) : (
          <>
            {renderSection('ordering', 'Ordering Parameters (dari sheet PARAMETER Excel)', Gear)}
            {renderSection('safety', 'Safety Stock Multipliers per Stock Status', Gear)}
            {renderSection('phase', 'Phase In / Out Classification', Gear)}

            <div className="flex gap-3 justify-end sticky bottom-4 bg-background p-4 border border-border rounded-lg shadow-lg">
              <Button variant="outline" onClick={handleReset} disabled={saving} className="gap-2" data-testid="param-reset">
                <ArrowClockwise size={16} />
                Reset ke Default
              </Button>
              <Button onClick={handleSave} disabled={saving} className="gap-2" data-testid="param-save">
                <FloppyDisk size={16} weight="fill" />
                {saving ? 'Menyimpan...' : 'Simpan Parameter'}
              </Button>
            </div>
          </>
        )}
      </div>
    </Layout>
  );
}
