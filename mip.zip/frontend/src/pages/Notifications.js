import React, { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { notificationAPI } from '../utils/api';
import { Bell, CheckCircle, Warning } from '@phosphor-icons/react';
import { formatDistanceToNow } from 'date-fns';
import { id as idLocale } from 'date-fns/locale';

export function Notifications() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadNotifications();
  }, []);

  const loadNotifications = async () => {
    setLoading(true);
    try {
      const response = await notificationAPI.getAll();
      setNotifications(response.data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div className="space-y-6 max-w-4xl">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">Alerts</p>
          <h1 className="text-3xl lg:text-4xl font-bold tracking-tight">Notifikasi</h1>
          <p className="text-muted-foreground mt-1">Alert untuk parts yang perlu di-order</p>
        </div>

        <Card className="border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell size={20} weight="fill" />
              Semua Notifikasi ({notifications.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {loading ? (
              <div className="p-12 text-center text-muted-foreground">Loading...</div>
            ) : notifications.length === 0 ? (
              <div className="p-12 text-center">
                <CheckCircle size={48} className="mx-auto text-green-500 mb-3" weight="fill" />
                <p className="text-muted-foreground">Tidak ada notifikasi</p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {notifications.map((notif, idx) => (
                  <div
                    key={idx}
                    className={`p-4 flex items-start gap-3 hover:bg-accent/50 transition-colors ${
                      !notif.read_status ? 'bg-primary/5' : ''
                    }`}
                    data-testid={`notification-${idx}`}
                  >
                    <div className="p-2 bg-red-500/10 rounded-md">
                      <Warning size={20} weight="fill" className="text-red-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{notif.message}</p>
                      {notif.branch && (
                        <p className="text-xs text-muted-foreground mt-1">{notif.branch}</p>
                      )}
                      <p className="text-xs text-muted-foreground mt-1">
                        {formatDistanceToNow(new Date(notif.created_at), { addSuffix: true, locale: idLocale })}
                      </p>
                    </div>
                    {!notif.read_status && (
                      <span className="w-2 h-2 bg-primary rounded-full mt-2"></span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
