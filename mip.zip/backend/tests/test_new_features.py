"""Tests for new features: parameters, dashboard MIP/SOQ split, SOQ upload/history."""
import os
import io
import pytest
import requests
from openpyxl import Workbook

BASE_URL = (os.environ.get("REACT_APP_BACKEND_URL") or "https://branch-parts-tracker.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"

ADMIN = {"email": "admin@toyota.com", "password": "Admin123!@#"}
MANAGER = {"email": "manager@toyota.com", "password": "Manager123!"}
PARTMAN = {"email": "partman@toyota.com", "password": "Partman123!"}
BRANCH = "PLAZA TOYOTA KYAI TAPA"


def _login(creds):
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json=creds, timeout=30)
    assert r.status_code == 200, r.text
    return s


def _make_mip_xlsx(prefix="NFP", count=5):
    wb = Workbook()
    ws = wb.active
    ws.append(["Product Number", "Product Description", "Qty on Hand", "Qty on Order",
               "Unit Cost", "Mar", "Apr", "Mei", "Jun"])
    # Item 1: Perlu Order (low stock high demand)
    ws.append([f"{prefix}-001", "Part Perlu Order", 2, 0, 50000, 15, 18, 20, 22])
    # Item 2: Over Stok
    ws.append([f"{prefix}-002", "Part Over Stok", 500, 0, 100000, 5, 6, 4, 5])
    # Item 3: Stop Order (no demand)
    ws.append([f"{prefix}-003", "Part Stop Order", 10, 0, 25000, 0, 0, 0, 0])
    # Item 4: Phase Out (freq 1)
    ws.append([f"{prefix}-004", "Phase Out Part", 3, 0, 30000, 5, 0, 0, 0])
    # Item 5: Normal
    ws.append([f"{prefix}-005", "Normal Part", 30, 0, 20000, 5, 6, 4, 5])
    buf = io.BytesIO(); wb.save(buf); buf.seek(0)
    return buf


def _upload_mip(session, prefix="NFP", branch=BRANCH):
    buf = _make_mip_xlsx(prefix)
    files = {"file": ("mip.xlsx", buf, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}
    r = session.post(f"{API}/inventory/upload", params={"branch": branch}, files=files, timeout=60)
    assert r.status_code == 200, r.text
    return r.json()


# ==================== PARAMETERS ====================
class TestParameters:
    def test_get_parameters_returns_defaults(self):
        s = _login(ADMIN)
        r = s.get(f"{API}/parameters", timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        assert "params" in data and "defaults" in data
        # Defaults sanity
        d = data["defaults"]
        assert d["working_days"] == 22
        assert d["fmv_multiplier"] == 1.0
        assert d["nmv_multiplier"] == 3.0
        assert d["phase_in_threshold"] == 3

    def test_partman_forced_to_own_branch(self):
        s = _login(PARTMAN)
        r = s.get(f"{API}/parameters", timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["branch"] == BRANCH

    def test_admin_update_branch_params(self):
        s = _login(ADMIN)
        # Update working days for KYAI TAPA
        r = s.put(f"{API}/parameters", params={"branch": BRANCH},
                  json={"working_days": 25, "fmv_multiplier": 1.5}, timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["params"]["working_days"] == 25
        assert data["params"]["fmv_multiplier"] == 1.5
        # Read back
        r2 = s.get(f"{API}/parameters", params={"branch": BRANCH}, timeout=30)
        assert r2.json()["params"]["working_days"] == 25
        # Reset for cleanup
        s.post(f"{API}/parameters/reset", params={"branch": BRANCH}, timeout=30)

    def test_partman_update_forbidden(self):
        s = _login(PARTMAN)
        r = s.put(f"{API}/parameters", json={"working_days": 30}, timeout=30)
        assert r.status_code == 403, r.text

    def test_manager_update_own_branch_only(self):
        s = _login(MANAGER)
        # Manager passes branch=TENDEAN but it should be overridden to their own branch
        r = s.put(f"{API}/parameters", params={"branch": "PLAZA TOYOTA TENDEAN"},
                  json={"working_days": 24}, timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        # forced to manager's branch
        assert data["branch"] == BRANCH
        # Cleanup
        s.post(f"{API}/parameters/reset", timeout=30)

    def test_reset_parameters(self):
        s = _login(ADMIN)
        s.put(f"{API}/parameters", params={"branch": BRANCH},
              json={"working_days": 99}, timeout=30)
        r = s.post(f"{API}/parameters/reset", params={"branch": BRANCH}, timeout=30)
        assert r.status_code == 200, r.text
        # Now GET should return default (22)
        r2 = s.get(f"{API}/parameters", params={"branch": BRANCH}, timeout=30)
        assert r2.json()["params"]["working_days"] == 22


# ==================== DASHBOARD MIP ====================
class TestDashboardMIP:
    def test_mip_dashboard_shape(self):
        s = _login(ADMIN)
        _upload_mip(s, prefix="MIPD")
        r = s.get(f"{API}/dashboard/mip", timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        for key in ("total_parts", "phase_in_count", "phase_out_count",
                    "total_gross_cost", "total_over_stok_cost",
                    "phase_breakdown", "stock_status_distribution"):
            assert key in data, f"Missing key {key}"
        assert data["total_parts"] >= 5
        # phase_breakdown items should have phase, count, gross_cost
        for p in data["phase_breakdown"]:
            for k in ("phase", "count", "gross_cost", "over_stok_cost"):
                assert k in p
        # gross cost > 0 given the uploaded qtys/unit_costs
        assert data["total_gross_cost"] > 0

    def test_mip_partman_scoped(self):
        s = _login(PARTMAN)
        r = s.get(f"{API}/dashboard/mip", timeout=30)
        assert r.status_code == 200, r.text


# ==================== DASHBOARD SOQ ====================
class TestDashboardSOQ:
    def test_soq_dashboard_shape(self):
        s = _login(ADMIN)
        _upload_mip(s, prefix="SOQD")
        r = s.get(f"{API}/dashboard/soq", timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        for key in ("perlu_order_count", "over_stok_count",
                    "total_order_units", "total_order_cost",
                    "total_over_units", "total_over_cost", "top_perlu_order"):
            assert key in data, f"Missing key {key}"
        # After uploading, we should have at least 1 Perlu Order
        assert data["perlu_order_count"] >= 1
        # top_perlu_order rows must include unit_cost + order_cost
        assert isinstance(data["top_perlu_order"], list)
        if data["top_perlu_order"]:
            top = data["top_perlu_order"][0]
            for k in ("product_number", "soq", "unit_cost", "order_cost"):
                assert k in top, f"Missing {k}"
            # order_cost = soq * unit_cost (rounded)
            assert abs(top["order_cost"] - round(top["soq"] * top["unit_cost"], 2)) < 0.01


# ==================== SOQ UPLOAD ====================
def _make_soq_xlsx(prefix="SOQU", updated=True):
    wb = Workbook()
    ws = wb.active
    ws.append(["Part Number", "On Hand", "On Order"])
    ws.append([f"{prefix}-001", 100 if updated else 2, 0])  # Boost stock -> should no longer perlu order
    ws.append([f"{prefix}-002", 10 if updated else 500, 0])  # Reduce stock
    ws.append(["NONEXISTENT-XYZ", 50, 0])  # not found
    buf = io.BytesIO(); wb.save(buf); buf.seek(0)
    return buf


class TestSOQUpload:
    def test_soq_upload_updates_existing_and_recalculates(self):
        s = _login(ADMIN)
        # Ensure MIP records exist for prefix SOQU
        _upload_mip(s, prefix="SOQU")
        # Snapshot MIP value for SOQU-001
        r0 = s.get(f"{API}/inventory", params={"branch": BRANCH, "limit": 500}, timeout=30)
        items = [i for i in r0.json()["items"] if i["product_number"].startswith("SOQU-")]
        assert len(items) >= 2
        soqu_001_before = next(i for i in items if i["product_number"] == "SOQU-001")
        original_mip = soqu_001_before["mip"]
        original_avg_demand = soqu_001_before["avg_demand"]

        # Upload SOQ daily
        buf = _make_soq_xlsx(prefix="SOQU", updated=True)
        files = {"file": ("soq.xlsx", buf, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}
        r = s.post(f"{API}/soq/upload", params={"branch": BRANCH}, files=files, timeout=60)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["updated_count"] == 2
        assert data["not_found_count"] == 1

        # Verify MIP unchanged, but qty_on_hand + soq updated
        r2 = s.get(f"{API}/inventory", params={"branch": BRANCH, "limit": 500}, timeout=30)
        soqu_001_after = next(i for i in r2.json()["items"] if i["product_number"] == "SOQU-001")
        assert soqu_001_after["mip"] == original_mip, "MIP must NOT change on SOQ upload"
        assert soqu_001_after["avg_demand"] == original_avg_demand
        assert soqu_001_after["qty_on_hand"] == 100

    def test_soq_upload_partman_restricted(self):
        s = _login(PARTMAN)
        buf = _make_soq_xlsx(prefix="SOQU", updated=True)
        files = {"file": ("soq.xlsx", buf, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}
        # Partman uploads without branch -> should use their own branch
        r = s.post(f"{API}/soq/upload", files=files, timeout=60)
        assert r.status_code == 200, r.text

    def test_soq_upload_manager_forbidden(self):
        s = _login(MANAGER)
        buf = _make_soq_xlsx(prefix="SOQU", updated=True)
        files = {"file": ("soq.xlsx", buf, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}
        r = s.post(f"{API}/soq/upload", params={"branch": BRANCH}, files=files, timeout=60)
        assert r.status_code == 403

    def test_soq_history(self):
        s = _login(ADMIN)
        # Trigger at least one SOQ upload to have history
        _upload_mip(s, prefix="SOQH")
        buf = _make_soq_xlsx(prefix="SOQH", updated=True)
        files = {"file": ("soq.xlsx", buf, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}
        s.post(f"{API}/soq/upload", params={"branch": BRANCH}, files=files, timeout=60)
        r = s.get(f"{API}/soq/history", timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        assert isinstance(data, list)
        assert len(data) >= 1
        e = data[0]
        for k in ("branch", "uploaded_at", "updated_count", "not_found_count"):
            assert k in e, f"Missing {k}"
