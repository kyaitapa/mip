import os
import pytest
import requests

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', 'https://branch-parts-tracker.preview.emergentagent.com').rstrip('/')
API = f"{BASE_URL}/api"
MGR_BRANCH = "PLAZA TOYOTA KYAI TAPA"


def _login(email, password):
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, r.text
    return s


@pytest.fixture(scope="module")
def admin():
    return _login("admin@toyota.com", "Admin123!@#")


@pytest.fixture(scope="module")
def manager():
    return _login("manager@toyota.com", "Manager123!")


def test_admin_get_global_params_empty_branch(admin):
    r = admin.get(f"{API}/parameters", params={"branch": ""})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["branch"] is None
    assert "params" in body


def test_admin_put_global_params_empty_branch_persists(admin):
    # Use non-default value 27
    r = admin.put(f"{API}/parameters", params={"branch": ""}, json={"working_days": 27})
    assert r.status_code == 200, r.text

    r2 = admin.get(f"{API}/parameters", params={"branch": ""})
    assert r2.status_code == 200
    body = r2.json()
    assert body["branch"] is None
    assert body["params"].get("working_days") == 27, body

    r3 = admin.get(f"{API}/parameters")
    assert r3.status_code == 200
    assert r3.json()["params"].get("working_days") == 27


def test_admin_reset_global_params_empty_branch(admin):
    r = admin.post(f"{API}/parameters/reset", params={"branch": ""})
    assert r.status_code == 200, r.text

    r2 = admin.get(f"{API}/parameters")
    assert r2.status_code == 200
    # After reset, global doc deleted, should return DEFAULT (22)
    assert r2.json()["params"].get("working_days") == 22


def test_admin_put_branch_specific_params_persists(admin):
    r = admin.put(f"{API}/parameters", params={"branch": MGR_BRANCH}, json={"fmv_multiplier": 1.5})
    assert r.status_code == 200, r.text

    r2 = admin.get(f"{API}/parameters", params={"branch": MGR_BRANCH})
    assert r2.status_code == 200
    body = r2.json()
    assert body["branch"] == MGR_BRANCH
    assert body["params"].get("fmv_multiplier") == 1.5, body

    admin.post(f"{API}/parameters/reset", params={"branch": MGR_BRANCH})


def test_manager_forced_to_own_branch_on_put(manager, admin):
    # Manager PUT with empty branch → must be forced to their own branch, NOT global
    r = manager.put(f"{API}/parameters", params={"branch": ""}, json={"working_days": 29})
    assert r.status_code == 200, r.text

    # Admin queries global - should NOT be 29 (default 22 since we reset above)
    r_global = admin.get(f"{API}/parameters", params={"branch": ""})
    assert r_global.status_code == 200
    assert r_global.json()["params"].get("working_days") != 29, r_global.json()

    # Admin queries manager branch - should be 29
    r_branch = admin.get(f"{API}/parameters", params={"branch": MGR_BRANCH})
    assert r_branch.status_code == 200
    assert r_branch.json()["params"].get("working_days") == 29, r_branch.json()

    # cleanup
    manager.post(f"{API}/parameters/reset")
