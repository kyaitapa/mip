import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { ChartLine, ShoppingCart, Upload, Bell, Users, SignOut, Package, List, ClockCounterClockwise, Gear, ArrowsClockwise } from '@phosphor-icons/react';
import { Button } from './ui/button';
import { notificationAPI } from '../utils/api';
import { toast } from 'sonner';

export function Sidebar() {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [notifCount, setNotifCount] = useState(0);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    loadNotifCount();
    const interval = setInterval(loadNotifCount, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadNotifCount = async () => {
    try {
      const r = await notificationAPI.getAll();
      setNotifCount(r.data.filter((n) => !n.read_status).length);
    } catch (e) { console.error(e); }
  };

  const handleLogout = async () => {
    try {
      await logout();
      toast.success('Logout berhasil');
      navigate('/login');
    } catch { toast.error('Gagal logout'); }
  };

  const menuGroups = [
    {
      label: 'Dashboard',
      items: [
        { path: '/dashboard/mip', label: 'Dashboard MIP', icon: ChartLine, roles: ['admin', 'manager', 'partman'] },
        { path: '/dashboard/soq', label: 'Dashboard SOQ', icon: ShoppingCart, roles: ['admin', 'manager', 'partman'] },
      ]
    },
    {
      label: 'Data',
      items: [
        { path: '/inventory', label: 'Inventory', icon: Package, roles: ['admin', 'manager', 'partman'] },
        { path: '/upload/mip', label: 'Upload MIP', icon: Upload, roles: ['admin', 'partman'] },
        { path: '/upload/soq', label: 'Upload SOQ', icon: ArrowsClockwise, roles: ['admin', 'partman'] },
        { path: '/history', label: 'History Upload', icon: ClockCounterClockwise, roles: ['admin', 'partman'] },
      ]
    },
    {
      label: 'Manajemen',
      items: [
        { path: '/notifications', label: 'Notifikasi', icon: Bell, roles: ['admin', 'manager', 'partman'], badge: notifCount },
        { path: '/parameters', label: 'Parameter MIP', icon: Gear, roles: ['admin', 'manager'] },
        { path: '/users', label: 'Kelola User', icon: Users, roles: ['admin'] },
      ]
    }
  ];

  const filteredGroups = menuGroups.map(g => ({
    ...g,
    items: g.items.filter(item => item.roles.includes(user?.role))
  })).filter(g => g.items.length > 0);

  return (
    <>
      <div className="lg:hidden fixed top-0 left-0 right-0 z-40 bg-card border-b border-border h-16 flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-sm">TM</span>
          </div>
          <span className="font-bold text-lg">Toyota MIP</span>
        </div>
        <Button variant="ghost" size="icon" onClick={() => setMobileOpen(!mobileOpen)} data-testid="mobile-menu-toggle">
          <List size={24} />
        </Button>
      </div>

      <aside className={`fixed lg:sticky top-0 left-0 h-screen w-64 bg-card border-r border-border flex flex-col z-30 transition-transform duration-300 ${mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="h-16 flex items-center gap-3 px-6 border-b border-border">
          <div className="w-10 h-10 bg-primary rounded-md flex items-center justify-center">
            <span className="text-primary-foreground font-bold">TM</span>
          </div>
          <div>
            <h1 className="font-bold text-base leading-none">Toyota MIP</h1>
            <p className="text-xs text-muted-foreground mt-0.5">Calculator</p>
          </div>
        </div>

        <div className="px-4 py-4 border-b border-border">
          <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">Signed in as</p>
          <p className="font-semibold text-sm truncate" data-testid="user-name">{user?.name}</p>
          <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
          <div className="inline-flex mt-2 px-2 py-0.5 bg-primary/10 text-primary text-xs font-medium rounded uppercase tracking-wide">
            {user?.role}
          </div>
          {user?.branch && <p className="text-xs text-muted-foreground mt-2 truncate">{user.branch}</p>}
        </div>

        <nav className="flex-1 px-3 py-3 space-y-4 overflow-y-auto">
          {filteredGroups.map((group, gi) => (
            <div key={gi} className="space-y-1">
              <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground px-3 mb-1 font-semibold">{group.label}</p>
              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path ||
                  (item.path === '/dashboard/mip' && location.pathname === '/dashboard');
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setMobileOpen(false)}
                    className={`flex items-center justify-between gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${isActive ? 'bg-primary text-primary-foreground' : 'text-foreground hover:bg-accent'}`}
                    data-testid={`nav-${item.path.replace(/\//g, '-').slice(1)}`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon size={18} weight={isActive ? 'fill' : 'regular'} />
                      <span>{item.label}</span>
                    </div>
                    {item.badge > 0 && (
                      <span className="bg-primary text-primary-foreground text-xs px-2 py-0.5 rounded-full font-semibold">{item.badge}</span>
                    )}
                  </Link>
                );
              })}
            </div>
          ))}
        </nav>

        <div className="p-3 border-t border-border">
          <Button variant="ghost" className="w-full justify-start gap-3 text-sm hover:bg-accent" onClick={handleLogout} data-testid="logout-button">
            <SignOut size={20} />
            <span>Logout</span>
          </Button>
        </div>
      </aside>

      {mobileOpen && <div className="lg:hidden fixed inset-0 bg-black/50 z-20" onClick={() => setMobileOpen(false)} />}
    </>
  );
}
