import axios from 'axios';

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const api = axios.create({
  baseURL: API,
  withCredentials: true
});

export const formatApiErrorDetail = (detail) => {
  if (detail == null) return 'Terjadi kesalahan. Silakan coba lagi.';
  if (typeof detail === 'string') return detail;
  if (Array.isArray(detail))
    return detail
      .map((e) => (e && typeof e.msg === 'string' ? e.msg : JSON.stringify(e)))
      .filter(Boolean)
      .join(' ');
  if (detail && typeof detail.msg === 'string') return detail.msg;
  return String(detail);
};

export const inventoryAPI = {
  upload: (formData) => api.post('/inventory/upload', formData),
  getAll: (params) => api.get('/inventory', { params }),
  exportExcel: (params) => api.get('/export/excel', { params, responseType: 'blob' }),
  exportPDF: (params) => api.get('/export/pdf', { params, responseType: 'blob' }),
  getHistory: () => api.get('/inventory/history'),
  deleteBatch: (params) => api.delete('/inventory', { params }),
  deleteAll: () => api.delete('/inventory', { params: { all_data: true } })
};

export const dashboardAPI = {
  getStats: (branch) => api.get('/dashboard/stats', { params: { branch } }),
  getMIPStats: (branch) => api.get('/dashboard/mip', { params: { branch } }),
  getSOQStats: (branch) => api.get('/dashboard/soq', { params: { branch } })
};

export const soqAPI = {
  upload: (formData, branch) => api.post('/soq/upload', formData, { params: { branch } }),
  getHistory: () => api.get('/soq/history')
};

export const parametersAPI = {
  get: (branch) => api.get('/parameters', { params: { branch } }),
  update: (data, branch) => api.put('/parameters', data, { params: { branch } }),
  reset: (branch) => api.post('/parameters/reset', {}, { params: { branch } })
};

export const branchAPI = {
  getAll: () => api.get('/branches')
};

export const notificationAPI = {
  getAll: () => api.get('/notifications'),
  markRead: (id) => api.put(`/notifications/${id}/read`)
};

export const userAPI = {
  getAll: () => api.get('/users')
};

export default api;