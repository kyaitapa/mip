import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ProtectedRoute } from './components/ProtectedRoute';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { DashboardMIP } from './pages/DashboardMIP';
import { DashboardSOQ } from './pages/DashboardSOQ';
import { Inventory } from './pages/Inventory';
import { Upload } from './pages/Upload';
import { UploadSOQ } from './pages/UploadSOQ';
import { Notifications } from './pages/Notifications';
import { Users } from './pages/Users';
import { History } from './pages/History';
import { Parameters } from './pages/Parameters';
import { Toaster } from 'sonner';
import '@/App.css';

function App() {
  return (
    <div className="App">
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard/mip" replace />} />
            <Route path="/dashboard" element={<Navigate to="/dashboard/mip" replace />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/dashboard/mip" element={<ProtectedRoute><DashboardMIP /></ProtectedRoute>} />
            <Route path="/dashboard/soq" element={<ProtectedRoute><DashboardSOQ /></ProtectedRoute>} />
            <Route path="/inventory" element={<ProtectedRoute><Inventory /></ProtectedRoute>} />
            <Route path="/upload/mip" element={<ProtectedRoute allowedRoles={['admin', 'partman']}><Upload /></ProtectedRoute>} />
            <Route path="/upload/soq" element={<ProtectedRoute allowedRoles={['admin', 'partman']}><UploadSOQ /></ProtectedRoute>} />
            <Route path="/upload" element={<Navigate to="/upload/mip" replace />} />
            <Route path="/notifications" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />
            <Route path="/users" element={<ProtectedRoute allowedRoles={['admin']}><Users /></ProtectedRoute>} />
            <Route path="/history" element={<ProtectedRoute allowedRoles={['admin', 'partman']}><History /></ProtectedRoute>} />
            <Route path="/parameters" element={<ProtectedRoute allowedRoles={['admin', 'manager']}><Parameters /></ProtectedRoute>} />
          </Routes>
        </BrowserRouter>
        <Toaster position="top-right" richColors />
      </AuthProvider>
    </div>
  );
}

export default App;
