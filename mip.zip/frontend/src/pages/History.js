import React, { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Button } from '../components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '../components/ui/alert-dialog';
import { inventoryAPI } from '../utils/api';
import { Trash, ClockCounterClockwise, Warning } from '@phosphor-icons/react';
import { toast } from 'sonner';

export function History() {
  const { user } = useAuth();
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deleteBusy, setDeleteBusy] = useState(false);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    setLoading(true);
    try {
      const response = await inventoryAPI.getHistory();
      setHistory(response.data);
    } catch (error) {
      toast.error('Gagal memuat history');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteBatch = async (batch) => {
    setDeleteBusy(true);
    try {
      const params = {
        upload_date_prefix: batch.upload_date
      };
      if (user?.role === 'admin') {
        params.branch = batch.branch;
      }
      const response = await inventoryAPI.deleteBatch(params);
      toast.success(`Berhasil hapus ${response.data.deleted_count} items`);
      await loadHistory();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Gagal menghapus data');
    } finally {
      setDeleteBusy(false);
    }
  };

  const handleDeleteAll = async () => {
    setDeleteBusy(true);
    try {
      const response = user?.role === 'admin'
        ? await inventoryAPI.deleteAll()
        : await inventoryAPI.deleteBatch({ branch: user.branch });
      toast.success(`Berhasil hapus ${response.data.deleted_count} items`);
      await loadHistory();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Gagal menghapus data');
    } finally {
      setDeleteBusy(false);
    }
  };

  const totalItems = history.reduce((sum, h) => sum + h.count, 0);

  return (
    <Layout>
      <div className="space-y-6 max-w-6xl">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">Data Management</p>
            <h1 className="text-3xl lg:text-4xl font-bold tracking-tight">Upload History</h1>
            <p className="text-muted-foreground mt-1">
              {history.length} batch upload · {totalItems.toLocaleString()} total items
            </p>
          </div>

          {history.length > 0 && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" className="gap-2" data-testid="delete-all-button">
                  <Trash size={18} weight="bold" />
                  Hapus Semua Data
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle className="flex items-center gap-2">
                    <Warning size={20} weight="fill" className="text-red-600" />
                    Hapus Semua Data Inventory?
                  </AlertDialogTitle>
                  <AlertDialogDescription>
                    Ini akan menghapus SEMUA data inventory {user?.role === 'partman' ? `cabang ${user.branch}` : 'di semua cabang'}.
                    Tindakan ini tidak bisa dibatalkan.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel data-testid="cancel-delete-all">Batal</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={handleDeleteAll}
                    disabled={deleteBusy}
                    className="bg-red-600 hover:bg-red-700"
                    data-testid="confirm-delete-all"
                  >
                    Ya, Hapus Semua
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>

        <Card className="border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ClockCounterClockwise size={20} weight="fill" />
              Riwayat Upload
            </CardTitle>
            <CardDescription>
              Batch upload dikelompokkan berdasarkan tanggal dan cabang. Anda bisa menghapus batch tertentu.
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 border-b border-border">
                  <tr>
                    <th className="text-left px-4 py-3 font-semibold uppercase text-xs tracking-wider">Tanggal Upload</th>
                    <th className="text-left px-4 py-3 font-semibold uppercase text-xs tracking-wider">Cabang</th>
                    <th className="text-right px-4 py-3 font-semibold uppercase text-xs tracking-wider">Total Items</th>
                    <th className="text-right px-4 py-3 font-semibold uppercase text-xs tracking-wider">Perlu Order</th>
                    <th className="text-center px-4 py-3 font-semibold uppercase text-xs tracking-wider">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan={5} className="text-center py-16 text-muted-foreground">Loading...</td>
                    </tr>
                  ) : history.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="text-center py-16 text-muted-foreground">
                        Belum ada upload. Upload data untuk melihat history di sini.
                      </td>
                    </tr>
                  ) : (
                    history.map((batch, idx) => (
                      <tr key={idx} className="border-b border-border hover:bg-accent/50 transition-colors" data-testid={`history-row-${idx}`}>
                        <td className="px-4 py-3 font-mono text-xs">{batch.upload_date}</td>
                        <td className="px-4 py-3">{batch.branch}</td>
                        <td className="px-4 py-3 text-right font-semibold">{batch.count.toLocaleString()}</td>
                        <td className="px-4 py-3 text-right">
                          {batch.perlu_order_count > 0 ? (
                            <span className="inline-flex items-center px-2 py-0.5 bg-red-500/10 text-red-600 rounded text-xs font-medium">
                              {batch.perlu_order_count}
                            </span>
                          ) : (
                            <span className="text-muted-foreground">0</span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-center">
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                data-testid={`delete-batch-${idx}`}
                              >
                                <Trash size={16} />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Hapus Batch Upload?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Menghapus {batch.count} items dari {batch.branch} yang di-upload pada {batch.upload_date}.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Batal</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => handleDeleteBatch(batch)}
                                  disabled={deleteBusy}
                                  className="bg-red-600 hover:bg-red-700"
                                  data-testid={`confirm-delete-batch-${idx}`}
                                >
                                  Hapus
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
