import React, { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { dashboardAPI, branchAPI } from '../utils/api';
import { Package, Warning, ArrowUp, CheckCircle, XCircle } from '@phosphor-icons/react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';

const STATUS_COLORS = {
  'Perlu Order': 'hsl(355, 92%, 48%)',
  'Over Stok': 'hsl(43, 96%, 56%)',
  'Stop Order': 'hsl(0, 0%, 40%)',
  'Normal': 'hsl(142, 71%, 45%)'
};

const STOCK_STATUS_COLORS = {
  FMV: 'hsl(142, 71%, 45%)',
  MMV: 'hsl(220, 70%, 50%)',
  SMV: 'hsl(43, 96%, 56%)',
  NMV: 'hsl(0, 0%, 40%)'
};

export function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [branches, setBranches] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState('all');

  useEffect(() => {
    loadBranches();
  }, []);

  useEffect(() => {
    loadStats();
  }, [selectedBranch]);

  const loadBranches = async () => {
    try {
      const response = await branchAPI.getAll();
      setBranches(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const loadStats = async () => {
    try {
      const branch = selectedBranch === 'all' ? '' : selectedBranch;
      const response = await dashboardAPI.getStats(branch);
      setStats(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const statusData = stats ? [
    { name: 'Perlu Order', value: stats.perlu_order, color: STATUS_COLORS['Perlu Order'] },
    { name: 'Over Stok', value: stats.over_stok, color: STATUS_COLORS['Over Stok'] },
    { name: 'Normal', value: stats.normal, color: STATUS_COLORS['Normal'] },
    { name: 'Stop Order', value: stats.stop_order, color: STATUS_COLORS['Stop Order'] }
  ] : [];

  const stockStatusData = stats?.stock_status_distribution?.map((item) => ({
    name: item._id || 'Unknown',
    count: item.count,
    color: STOCK_STATUS_COLORS[item._id] || 'hsl(0, 0%, 40%)'
  })) || [];

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">Overview</p>
            <h1 className="text-3xl lg:text-4xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-muted-foreground mt-1">Selamat datang, {user?.name}</p>
          </div>
          {user?.role !== 'partman' && (
            <Select value={selectedBranch} onValueChange={setSelectedBranch}>
              <SelectTrigger className="w-full sm:w-64" data-testid="branch-filter">
                <SelectValue placeholder="Pilih Cabang" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Cabang</SelectItem>
                {branches.map((branch) => (
                  <SelectItem key={branch.code} value={branch.name}>
                    {branch.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <StatCard title="Total Parts" value={stats?.total_parts || 0} icon={Package} color="bg-blue-500/10 text-blue-600" testId="stat-total-parts" />
          <StatCard title="Perlu Order" value={stats?.perlu_order || 0} icon={Warning} color="bg-red-500/10 text-red-600" testId="stat-perlu-order" />
          <StatCard title="Over Stok" value={stats?.over_stok || 0} icon={ArrowUp} color="bg-yellow-500/10 text-yellow-600" testId="stat-over-stok" />
          <StatCard title="Normal" value={stats?.normal || 0} icon={CheckCircle} color="bg-green-500/10 text-green-600" testId="stat-normal" />
          <StatCard title="Stop Order" value={stats?.stop_order || 0} icon={XCircle} color="bg-gray-500/10 text-gray-600" testId="stat-stop-order" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="border-border">
            <CardHeader>
              <CardTitle className="text-xl">Distribusi Status Inventory</CardTitle>
            </CardHeader>
            <CardContent>
              {statusData.some(d => d.value > 0) ? (
                <ResponsiveContainer width="100%" height={320}>
                  <PieChart>
                    <Pie
                      data={statusData.filter(d => d.value > 0)}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={110}
                      paddingAngle={2}
                      dataKey="value"
                      label={(entry) => `${entry.name}: ${entry.value}`}
                    >
                      {statusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-80 flex items-center justify-center text-muted-foreground">
                  Belum ada data. Upload data inventory untuk melihat statistik.
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader>
              <CardTitle className="text-xl">Stock Status Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              {stockStatusData.length > 0 ? (
                <ResponsiveContainer width="100%" height={320}>
                  <BarChart data={stockStatusData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
                    <YAxis stroke="hsl(var(--muted-foreground))" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))'
                      }}
                    />
                    <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                      {stockStatusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-80 flex items-center justify-center text-muted-foreground">
                  Belum ada data
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-xl">Info MIP Calculator</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
              <div className="space-y-2">
                <p className="font-semibold text-foreground uppercase tracking-wider text-xs">Formula MIP</p>
                <p className="text-muted-foreground">MIP = (Avg.Dmd × Avg.L/T) + SS L/T + SS Dmd</p>
                <p className="text-muted-foreground">SOQ = MIP − (Qty on Hand + Qty on Order)</p>
              </div>
              <div className="space-y-2">
                <p className="font-semibold text-foreground uppercase tracking-wider text-xs">Stock Status</p>
                <div className="grid grid-cols-2 gap-2">
                  <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-green-500"></span> FMV: Fast Moving</div>
                  <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-blue-500"></span> MMV: Medium Moving</div>
                  <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-yellow-500"></span> SMV: Slow Moving</div>
                  <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-gray-500"></span> NMV: Non Moving</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}

function StatCard({ title, value, icon: Icon, color, testId }) {
  return (
    <Card className="border-border hover:-translate-y-1 transition-transform duration-200" data-testid={testId}>
      <CardContent className="pt-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground font-medium">{title}</p>
            <p className="text-3xl font-bold mt-2 tracking-tight">{value.toLocaleString()}</p>
          </div>
          <div className={`p-2 rounded-md ${color}`}>
            <Icon size={24} weight="fill" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
