import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { inventoryAPI, branchAPI } from '../utils/api';
import { UploadSimple, FileXls, CheckCircle } from '@phosphor-icons/react';
import { toast } from 'sonner';

export function Upload() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const [file, setFile] = useState(null);
  const [branches, setBranches] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState(user?.branch || '');
  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState(null);
  const [dragActive, setDragActive] = useState(false);

  useEffect(() => {
    loadBranches();
  }, []);

  const loadBranches = async () => {
    try {
      const response = await branchAPI.getAll();
      setBranches(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleFileChange = (selectedFile) => {
    if (!selectedFile) return;
    if (!selectedFile.name.match(/\.(xlsx|xls)$/i)) {
      toast.error('File harus berformat Excel (.xlsx atau .xls)');
      return;
    }
    setFile(selectedFile);
    setResult(null);
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileChange(e.dataTransfer.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!file) {
      toast.error('Pilih file terlebih dahulu');
      return;
    }
    if (!selectedBranch && user?.role === 'admin') {
      toast.error('Pilih cabang terlebih dahulu');
      return;
    }

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('branch', selectedBranch);
      
      const response = await inventoryAPI.upload(formData);
      setResult(response.data);
      toast.success(response.data.message);
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Upload gagal');
    } finally {
      setUploading(false);
    }
  };

  return (
    <Layout>
      <div className="space-y-6 max-w-4xl">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-1">Import Data</p>
          <h1 className="text-3xl lg:text-4xl font-bold tracking-tight">Upload Inventory Data</h1>
          <p className="text-muted-foreground mt-1">Upload file Excel dengan data inventory dan demand</p>
        </div>

        <Card className="border-border">
          <CardHeader>
            <CardTitle>Format File Excel</CardTitle>
            <CardDescription>File harus memiliki kolom berikut:</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
              {[
                'Product Number', 'Product Description', 'Qty on Hand', 'Qty on Order',
                'Unit Cost', 'Mar', 'Apr', 'Mei', 'Jun'
              ].map((col) => (
                <div key={col} className="bg-muted/50 px-3 py-2 rounded font-mono text-xs">
                  {col}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-border">
          <CardHeader>
            <CardTitle>Upload File</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {user?.role === 'admin' && (
              <div>
                <label className="text-sm font-medium mb-2 block">Pilih Cabang</label>
                <Select value={selectedBranch} onValueChange={setSelectedBranch}>
                  <SelectTrigger data-testid="upload-branch-select">
                    <SelectValue placeholder="Pilih cabang" />
                  </SelectTrigger>
                  <SelectContent>
                    {branches.map((b) => (
                      <SelectItem key={b.code} value={b.name}>{b.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-colors ${
                dragActive ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
              }`}
              data-testid="upload-dropzone"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xls"
                className="hidden"
                onChange={(e) => handleFileChange(e.target.files?.[0])}
                data-testid="file-input"
              />
              {file ? (
                <div className="flex items-center justify-center gap-3">
                  <FileXls size={48} weight="fill" className="text-green-600" />
                  <div className="text-left">
                    <p className="font-semibold">{file.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {(file.size / 1024).toFixed(2)} KB
                    </p>
                  </div>
                </div>
              ) : (
                <>
                  <UploadSimple size={48} className="mx-auto text-muted-foreground mb-4" />
                  <p className="font-medium">Klik atau drag file ke sini</p>
                  <p className="text-xs text-muted-foreground mt-1">Hanya file .xlsx atau .xls</p>
                </>
              )}
            </div>

            <div className="flex gap-3">
              <Button
                onClick={handleUpload}
                disabled={!file || uploading}
                className="flex-1"
                data-testid="upload-submit-button"
              >
                {uploading ? 'Uploading...' : 'Upload & Hitung MIP'}
              </Button>
              {file && (
                <Button
                  variant="outline"
                  onClick={() => { setFile(null); setResult(null); }}
                  data-testid="clear-file-button"
                >
                  Clear
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {result && (
          <Card className="border-border" data-testid="upload-result">
            <CardHeader>
              <div className="flex items-center gap-3">
                <CheckCircle size={24} weight="fill" className="text-green-600" />
                <CardTitle>Upload Berhasil</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <p><span className="text-muted-foreground">Total items uploaded:</span> <span className="font-bold">{result.uploaded_count}</span></p>
              {result.errors && result.errors.length > 0 && (
                <div>
                  <p className="text-sm font-medium text-red-600 mb-2">Errors ({result.errors.length}):</p>
                  <ul className="text-xs text-muted-foreground space-y-1 max-h-40 overflow-y-auto">
                    {result.errors.map((err, i) => (
                      <li key={i}>{err}</li>
                    ))}
                  </ul>
                </div>
              )}
              <Button onClick={() => navigate('/inventory')} className="mt-4" data-testid="view-inventory-button">
                Lihat Data Inventory
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
}
